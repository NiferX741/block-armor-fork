package twopiradians.blockArmor.client;

import com.google.common.collect.Maps;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.util.Tuple;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.ClientRegistry;
import net.minecraftforge.client.event.ModelBakeEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.client.event.TextureStitchEvent.Pre;
import net.minecraftforge.client.model.ForgeModelBakery;
import net.minecraftforge.client.model.ModelLoaderRegistry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import twopiradians.blockArmor.client.key.KeyActivateSetEffect;
import twopiradians.blockArmor.client.model.ModelBAArmor;
import twopiradians.blockArmor.client.model.ModelBAItem;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.CommonProxy;
import twopiradians.blockArmor.common.block.ModBlocks;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.common.item.BlockArmorItem;
import twopiradians.blockArmor.common.item.ModItems;
import twopiradians.blockArmor.common.item.TextureOverrideInfo;
import twopiradians.blockArmor.common.seteffect.SetEffectHoarder;

@EventBusSubscriber({Dist.CLIENT})
public class ClientProxy {
   private static HashMap<String, ModelBAArmor> modelMaps = Maps.newHashMap();
   public static ForgeModelBakery modelLoader;
   private static Map<ResourceLocation, BakedModel> bakedModelRegistry;
   private static final Field UNBAKED_MODELS_FIELD = ObfuscationReflectionHelper.findField(ModelBakery.class, "f_119212_");
   private static final Method LOAD_MODEL_METHOD = ObfuscationReflectionHelper.findMethod(ModelBakery.class, "m_119364_", new Class[]{ResourceLocation.class});

   public static void setWorldTime(Level world, long time) {
      if (world instanceof ClientLevel) {
         ((ClientLevel)world).setDayTime(time);
      } else {
         CommonProxy.setWorldTime(world, time);
      }
   }

   public static void mapUnbakedModels() {
      try {
         Map<ResourceLocation, UnbakedModel> unbakedModels = (Map<ResourceLocation, UnbakedModel>)UNBAKED_MODELS_FIELD.get(ForgeModelBakery.instance());
         if (!ArmorSet.allSets.isEmpty() && ArmorSet.allSets.get(0).helmet != null) {
            UnbakedModel currentModel = unbakedModels.get(new ModelResourceLocation(ArmorSet.allSets.get(0).helmet.getRegistryName(), "inventory"));
            if (currentModel == null || currentModel == ModelBakery.MISSING_MODEL_LOCATION) {
               BlockModel model = (BlockModel)LOAD_MODEL_METHOD.invoke(
                  ForgeModelBakery.instance(), new ModelResourceLocation(new ResourceLocation("blockarmor", "item/block_armor"), "inventory")
               );

               for (ArmorSet set : ArmorSet.allSets) {
                  for (EquipmentSlot slot : ArmorSet.SLOTS) {
                     BlockArmorItem item = set.getArmorForSlot(slot);
                     unbakedModels.put(new ModelResourceLocation(item.getRegistryName(), "inventory"), model);
                  }
               }
            }
         }
      } catch (Exception var10) {
         var10.printStackTrace();
      }
   }

   public static void setup() {
      KeyActivateSetEffect.ACTIVATE_SET_EFFECT = new KeyMapping("Activate Set Effect", 82, "Block Armor");
      ClientRegistry.registerKeyBinding(KeyActivateSetEffect.ACTIVATE_SET_EFFECT);
      registerScreenContainerTypes();
   }

   @OnlyIn(Dist.CLIENT)
   public static void registerScreenContainerTypes() {
      MenuScreens.register(SetEffectHoarder.containerType_9x1, ContainerScreen::new);
      MenuScreens.register(SetEffectHoarder.containerType_9x2, ContainerScreen::new);
      MenuScreens.register(SetEffectHoarder.containerType_9x3, ContainerScreen::new);
      MenuScreens.register(SetEffectHoarder.containerType_9x4, ContainerScreen::new);
      MenuScreens.register(SetEffectHoarder.containerType_9x5, ContainerScreen::new);
      MenuScreens.register(SetEffectHoarder.containerType_9x6, ContainerScreen::new);
   }

   public static Object getBlockArmorModel(LivingEntity entity, int height, int width, int currentFrame, int nextFrame, EquipmentSlot slot) {
      String key = height + "_" + width + "_" + currentFrame + "_" + nextFrame + "_" + slot.getName();
      ModelBAArmor model = modelMaps.get(key);
      if (model == null) {
         model = new ModelBAArmor(height, width, currentFrame, nextFrame, slot);
         modelMaps.put(key, model);
      }

      model.entity = entity;
      return model;
   }

   public static void mapTextures() {
      modelMaps = Maps.newHashMap();
      ArrayList<ArmorSet> setsToDisable = new ArrayList<>();
      int numTextures = 0;

      for (ArmorSet set : ArmorSet.allSets) {
         Tuple<Integer, Boolean> tup = set.initTextures();
         numTextures += tup.getA();
         if ((Boolean)tup.getB()) {
            setsToDisable.add(set);
         }
      }

      if (numTextures != 0) {
         if (!setsToDisable.isEmpty()) {
            int disabledSets = 0;

            for (ArmorSet setx : setsToDisable) {
               setx.missingTextures = true;
               setx.disable();
               disabledSets++;
            }

            BlockArmor.LOGGER.info("Disabled " + disabledSets + " armor set" + (disabledSets > 1 ? "s" : "") + " without textures");
         }

         BlockArmor.LOGGER.info("Found " + numTextures + " block textures for Block Armor");
         ModelBakery bakery = modelLoader != null ? modelLoader : ForgeModelBakery.instance();
         int numIcons = ModelBAItem.BakedDynBlockArmorOverrideHandler.createInventoryIcons(bakery);
         BlockArmor.LOGGER.info("Created " + numIcons + " inventory icons for Block Armor");
      } else {
         ModelBAItem.BakedDynBlockArmorOverrideHandler.ITEM_MODELS.clear();
      }

      installArmorModels();
   }

   public static void installArmorModels() {
      if (bakedModelRegistry == null) {
         return;
      }

      for (ArmorSet set : ArmorSet.allSets) {
         for (EquipmentSlot slot : ArmorSet.SLOTS) {
            BlockArmorItem item = set.getArmorForSlot(slot);
            if (item == null || item.getRegistryName() == null) {
               continue;
            }

            BakedModel model = ModelBAItem.BakedDynBlockArmorOverrideHandler.ITEM_MODELS.get(item);
            if (model == null) {
               continue;
            }

            bakedModelRegistry.put(new ModelResourceLocation(item.getRegistryName(), "inventory"), model);
         }
      }
   }

   @EventBusSubscriber(
      value = {Dist.CLIENT},
      bus = Bus.MOD
   )
   public static class RegistrationHandler {
      @SubscribeEvent
      public static void textureStitch(Pre event) {
         if (TextureAtlas.LOCATION_BLOCKS.equals(event.getAtlas().location())) {
            for (TextureOverrideInfo override : ArmorSet.TEXTURE_OVERRIDES.values()) {
               for (TextureOverrideInfo.Info info : override.overrides.values()) {
                  event.addSprite(info.shortLoc);
               }
            }

            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_helmet_base"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_helmet_cover"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_helmet1_template"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_helmet2_template"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_chestplate_base"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_chestplate_cover"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_chestplate1_template"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_chestplate2_template"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_leggings_base"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_leggings_cover"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_leggings1_template"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_leggings2_template"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_boots_base"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_boots_cover"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_boots1_template"));
            event.addSprite(new ResourceLocation("blockarmor", "items/icons/block_armor_boots2_template"));
         }
      }

      @SubscribeEvent
      public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
         event.registerReloadListener((ResourceManagerReloadListener)resourceManager -> ClientProxy.mapTextures());
      }

      @SubscribeEvent
      public static void onModelBake(ModelBakeEvent event) {
         ClientProxy.modelLoader = event.getModelLoader();
         ClientProxy.bakedModelRegistry = event.getModelRegistry();
         ModItems.registerRenders();
         ModBlocks.registerRenders();
         BakedModel shell = ModelBAItem.createShell();

         for (ArmorSet set : ArmorSet.allSets) {
            for (EquipmentSlot slot : ArmorSet.SLOTS) {
               BlockArmorItem item = set.getArmorForSlot(slot);
               if (item == null || item.getRegistryName() == null) {
                  continue;
               }

               event.getModelRegistry().put(new ModelResourceLocation(item.getRegistryName(), "inventory"), shell);
            }
         }
      }

      @SubscribeEvent
      public static void onModelRegister(ModelRegistryEvent event) {
         ModelLoaderRegistry.registerLoader(new ResourceLocation("blockarmor", "item_loader"), ModelBAItem.LoaderDynBlockArmor.INSTANCE);
      }
   }
}
