package twopiradians.blockArmor.client.key;

import java.util.UUID;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent.ClientTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.packet.CActivateSetEffectPacket;

@EventBusSubscriber({Dist.CLIENT})
public class KeyActivateSetEffect {
   @OnlyIn(Dist.CLIENT)
   public static KeyMapping ACTIVATE_SET_EFFECT;

   @SubscribeEvent
   public static void playerTick(ClientTickEvent event) {
      if (event.phase == Phase.END && Minecraft.getInstance().player != null) {
         UUID player = Minecraft.getInstance().player.getUUID();
         Boolean previous = BlockArmor.key.isKeyDown.get(player);
         if (previous == null || ACTIVATE_SET_EFFECT.isDown() != previous) {
            BlockArmor.key.isKeyDown.put(player, ACTIVATE_SET_EFFECT.isDown());
            BlockArmor.NETWORK.sendToServer(new CActivateSetEffectPacket(ACTIVATE_SET_EFFECT.isDown(), player));
         }
      }
   }
}
