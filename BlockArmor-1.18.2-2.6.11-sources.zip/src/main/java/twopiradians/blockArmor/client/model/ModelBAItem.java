package twopiradians.blockArmor.client.model;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.datafixers.util.Pair;
import com.mojang.math.Quaternion;
import com.mojang.math.Transformation;
import com.mojang.math.Vector3f;
import java.awt.Color;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.function.Function;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.block.model.ItemTransforms.TransformType;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.Material;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.model.BlockModelConfiguration;
import net.minecraftforge.client.model.CompositeModelState;
import net.minecraftforge.client.model.IModelConfiguration;
import net.minecraftforge.client.model.IModelLoader;
import net.minecraftforge.client.model.ItemLayerModel;
import net.minecraftforge.client.model.ItemTextureQuadConverter;
import net.minecraftforge.client.model.PerspectiveMapWrapper;
import net.minecraftforge.client.model.SimpleModelState;
import net.minecraftforge.client.model.geometry.IModelGeometry;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.common.item.BlockArmorItem;

@OnlyIn(Dist.CLIENT)
public final class ModelBAItem implements IModelGeometry<ModelBAItem> {
   public static final ModelResourceLocation LOCATION = new ModelResourceLocation("blockarmor:block_armor", "inventory");
   private static final float NORTH_Z_BASE = 0.4685F;
   private static final float SOUTH_Z_BASE = 0.5314375F;
   private static final float NORTH_Z_FLUID = 0.468625F;
   private static final float SOUTH_Z_FLUID = 0.531375F;

   public Collection getTextures(IModelConfiguration owner, Function modelGetter, Set missingTextureErrors) {
      return ImmutableSet.builder().build();
   }

   public BakedModel bake(
      IModelConfiguration owner, ModelBakery bakery, Function spriteGetter, ModelState modelTransform, ItemOverrides overrides, ResourceLocation modelLocation
   ) {
      return new ModelBAItem.BakedDynBlockArmor();
   }

   public static BakedModel createShell() {
      return new ModelBAItem.BakedDynBlockArmor();
   }

   private static final class BakedDynBlockArmor implements BakedModel {
      @Nullable
      public final ModelBAItem.Layer layer;
      private HashMap<ModelBAItem.Layer, ModelBAItem.BakedDynBlockArmor> layers = Maps.newHashMap();
      private final ImmutableMap<TransformType, Transformation> transforms;
      private ImmutableList<BakedQuad> quads = ImmutableList.of();
      private TextureAtlasSprite particles;

      public BakedDynBlockArmor() {
         this(null);

         for (ModelBAItem.Layer layer : ModelBAItem.Layer.values()) {
            this.layers.put(layer, new ModelBAItem.BakedDynBlockArmor(layer));
         }
      }

      private BakedDynBlockArmor(ModelBAItem.Layer layer) {
         this.layer = layer;
         Builder<TransformType, Transformation> builder = ImmutableMap.builder();
         builder.put(
            TransformType.GROUND,
            new Transformation(
               new Vector3f(0.0F, 0.125F, 0.0F), new Quaternion(0.0F, 0.0F, 0.0F, 1.0F), new Vector3f(0.5F, 0.5F, 0.5F), new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder.put(
            TransformType.HEAD,
            new Transformation(
               new Vector3f(0.0F, 0.8125F, 0.4375F),
               new Quaternion(0.0F, 1.0F, 0.0F, -4.371139E-8F),
               new Vector3f(1.0F, 1.0F, 1.0F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder.put(
            TransformType.FIRST_PERSON_RIGHT_HAND,
            new Transformation(
               new Vector3f(0.070625F, 0.2F, 0.070625F),
               new Quaternion(-0.15304594F, -0.6903456F, 0.15304594F, 0.6903456F),
               new Vector3f(0.68000007F, 0.68000007F, 0.68F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder.put(
            TransformType.FIRST_PERSON_LEFT_HAND,
            new Transformation(
               new Vector3f(0.070625F, 0.2F, 0.070625F),
               new Quaternion(-0.15304594F, -0.6903456F, 0.15304594F, 0.6903456F),
               new Vector3f(0.68000007F, 0.68000007F, 0.68F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder.put(
            TransformType.THIRD_PERSON_RIGHT_HAND,
            new Transformation(
               new Vector3f(0.0F, 0.1875F, 0.0625F),
               new Quaternion(0.0F, 0.0F, 0.0F, 0.99999994F),
               new Vector3f(0.55F, 0.55F, 0.55F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder.put(
            TransformType.THIRD_PERSON_LEFT_HAND,
            new Transformation(
               new Vector3f(0.0F, 0.1875F, 0.0625F),
               new Quaternion(0.0F, 0.0F, 0.0F, 0.99999994F),
               new Vector3f(0.55F, 0.55F, 0.55F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         ImmutableMap<TransformType, Transformation> transformMap = builder.build();
         this.transforms = Maps.immutableEnumMap(transformMap);
      }

      public ItemOverrides getOverrides() {
         return ModelBAItem.BakedDynBlockArmorOverrideHandler.INSTANCE;
      }

      public BakedModel handlePerspective(TransformType cameraTransformType, PoseStack mat) {
         return PerspectiveMapWrapper.handlePerspective(this, this.transforms, cameraTransformType, mat);
      }

      public List<BakedQuad> getQuads(BlockState state, Direction side, Random rand) {
         return side == null ? this.quads : ImmutableList.of();
      }

      public List<Pair<BakedModel, RenderType>> getLayerModels(ItemStack stack, boolean fabulous) {
         List<Pair<BakedModel, RenderType>> ret = Lists.newArrayList();

         for (ModelBAItem.Layer layer : ModelBAItem.Layer.values()) {
            ret.add(Pair.of(this.layers.get(layer), layer.getRenderType(stack)));
         }

         return ret;
      }

      public boolean isLayered() {
         // JEI draws item icons through getQuads. Layered models leave that list empty,
         // so the recipe slot stays a blank gray square.
         return false;
      }

      public boolean usesBlockLight() {
         return false;
      }

      public boolean useAmbientOcclusion() {
         return true;
      }

      public boolean isGui3d() {
         return false;
      }

      public boolean isCustomRenderer() {
         return false;
      }

      public TextureAtlasSprite getParticleIcon() {
         if (this.particles != null) {
            return this.particles;
         }

         return Minecraft.getInstance().getModelManager().getMissingModel().getParticleIcon();
      }

      public ItemTransforms getTransforms() {
         return ItemTransforms.NO_TRANSFORMS;
      }
   }

   public static final class BakedDynBlockArmorOverrideHandler extends ItemOverrides {
      public static final HashMap<Item, ModelBAItem.BakedDynBlockArmor> ITEM_MODELS = Maps.newHashMap();
      public static final ModelBAItem.BakedDynBlockArmorOverrideHandler INSTANCE = new ModelBAItem.BakedDynBlockArmorOverrideHandler();

      public static int createInventoryIcons(final ModelBakery bakery) {
         if (bakery == null) {
            BlockArmor.LOGGER.warn("Block Armor icons skipped: model bakery is not ready");
            return 0;
         }

         TextureAtlas blocksAtlas;
         try {
            blocksAtlas = Minecraft.getInstance().getModelManager().getAtlas(TextureAtlas.LOCATION_BLOCKS);
         } catch (RuntimeException ex) {
            BlockArmor.LOGGER.warn("Block Armor icons skipped: block atlas is not ready");
            return 0;
         }

         HashMap<Item, ModelBAItem.BakedDynBlockArmor> built = Maps.newHashMap();
         int numIcons = 0;
         Builder<TransformType, Transformation> builder2 = ImmutableMap.builder();
         builder2.put(
            TransformType.GROUND,
            new Transformation(
               new Vector3f(0.0F, 0.125F, 0.0F), new Quaternion(0.0F, 0.0F, 0.0F, 1.0F), new Vector3f(0.5F, 0.5F, 0.5F), new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder2.put(
            TransformType.HEAD,
            new Transformation(
               new Vector3f(0.0F, 0.8125F, 0.4375F),
               new Quaternion(0.0F, 1.0F, 0.0F, -4.371139E-8F),
               new Vector3f(1.0F, 1.0F, 1.0F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder2.put(
            TransformType.FIRST_PERSON_RIGHT_HAND,
            new Transformation(
               new Vector3f(0.070625F, 0.2F, 0.070625F),
               new Quaternion(-0.15304594F, -0.6903456F, 0.15304594F, 0.6903456F),
               new Vector3f(0.68000007F, 0.68000007F, 0.68F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder2.put(
            TransformType.FIRST_PERSON_LEFT_HAND,
            new Transformation(
               new Vector3f(0.070625F, 0.2F, 0.070625F),
               new Quaternion(-0.15304594F, -0.6903456F, 0.15304594F, 0.6903456F),
               new Vector3f(0.68000007F, 0.68000007F, 0.68F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder2.put(
            TransformType.THIRD_PERSON_RIGHT_HAND,
            new Transformation(
               new Vector3f(0.0F, 0.1875F, 0.0625F),
               new Quaternion(0.0F, 0.0F, 0.0F, 0.99999994F),
               new Vector3f(0.55F, 0.55F, 0.55F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         builder2.put(
            TransformType.THIRD_PERSON_LEFT_HAND,
            new Transformation(
               new Vector3f(0.0F, 0.1875F, 0.0625F),
               new Quaternion(0.0F, 0.0F, 0.0F, 0.99999994F),
               new Vector3f(0.55F, 0.55F, 0.55F),
               new Quaternion(0.0F, 0.0F, 0.0F, 1.0F)
            )
         );
         ImmutableMap<TransformType, Transformation> transformMap = builder2.build();

         for (ArmorSet set : ArmorSet.allSets) {
            BlockArmorItem[] armor = new BlockArmorItem[]{set.helmet, set.chestplate, set.leggings, set.boots};

            for (BlockArmorItem item : armor) {
               if (item != null) {
                  TextureAtlasSprite sprite = item.set.getTextureInfo(item.getSlot()).sprite;
                  if (sprite == null) {
                     BlockArmor.LOGGER.warn("Missing sprite for: " + new ItemStack(item).getHoverName().getContents());
                     continue;
                  }

                  ModelState state = new SimpleModelState(transformMap);
                  Transformation transform = Transformation.identity();
                  state = new CompositeModelState(state, state);
                  String armorType = "";
                  EquipmentSlot slot = item.getSlot();
                  if (slot == EquipmentSlot.HEAD) {
                     armorType = "helmet";
                  } else if (slot == EquipmentSlot.CHEST) {
                     armorType = "chestplate";
                  } else if (slot == EquipmentSlot.LEGS) {
                     armorType = "leggings";
                  } else if (slot == EquipmentSlot.FEET) {
                     armorType = "boots";
                  }

                  ResourceLocation baseLocation = new ResourceLocation("blockarmor:items/icons/block_armor_" + armorType + "_base");
                  BakedModel model = new ItemLayerModel(ImmutableList.of(new Material(TextureAtlas.LOCATION_BLOCKS, baseLocation)))
                     .bake(
                        new BlockModelConfiguration(
                           new BlockModel(
                              baseLocation, Lists.newArrayList(), Maps.newHashMap(), false, null, ItemTransforms.NO_TRANSFORMS, Lists.newArrayList()
                           )
                        ),
                        bakery,
                        new Function<Material, TextureAtlasSprite>() {
                           public TextureAtlasSprite apply(Material mat) {
                              return blocksAtlas.getSprite(mat.texture());
                           }
                        },
                        state,
                        INSTANCE,
                        baseLocation
                     );
                  com.google.common.collect.ImmutableList.Builder<BakedQuad> builder = ImmutableList.builder();
                  HashMap<ModelBAItem.Layer, ImmutableList<BakedQuad>> quads = Maps.newHashMap();
                  builder.addAll(model.getQuads(null, null, new Random()));
                  quads.put(ModelBAItem.Layer.BASE, builder.build());
                  int color = item.set.getTextureInfo(item.getSlot()).color;
                  if (color != -1) {
                     float r = (float)(color >> 16 & 0xFF) / 255.0F;
                     float g = (float)(color >> 8 & 0xFF) / 255.0F;
                     float b = (float)(color >> 0 & 0xFF) / 255.0F;
                     color = new Color(r, g, b, 1.0F).getRGB();
                  }

                  builder = ImmutableList.builder();
                  ResourceLocation templateLocation = new ResourceLocation("blockarmor:items/icons/block_armor_" + armorType + "1_template");
                  TextureAtlasSprite templateTexture = blocksAtlas.getSprite(templateLocation);
                  builder.addAll(ItemTextureQuadConverter.convertTexture(transform, templateTexture, sprite, 0.468625F, Direction.NORTH, color, 1));
                  builder.addAll(ItemTextureQuadConverter.convertTexture(transform, templateTexture, sprite, 0.531375F, Direction.SOUTH, color, 1));
                  templateLocation = new ResourceLocation("blockarmor:items/icons/block_armor_" + armorType + "2_template");
                  templateTexture = blocksAtlas.getSprite(templateLocation);
                  builder.addAll(ItemTextureQuadConverter.convertTexture(transform, templateTexture, sprite, 0.468625F, Direction.NORTH, color, 1));
                  builder.addAll(ItemTextureQuadConverter.convertTexture(transform, templateTexture, sprite, 0.531375F, Direction.SOUTH, color, 1));
                  quads.put(ModelBAItem.Layer.TEMPLATE, builder.build());
                  builder = ImmutableList.builder();
                  ResourceLocation coverLocation = new ResourceLocation("blockarmor:items/icons/block_armor_" + armorType + "_cover");
                  TextureAtlasSprite coverTexture = blocksAtlas.getSprite(coverLocation);
                  builder.add(ItemTextureQuadConverter.genQuad(transform, 0.0F, 0.0F, 16.0F, 16.0F, 0.4685F, coverTexture, Direction.NORTH, color, 1));
                  builder.add(ItemTextureQuadConverter.genQuad(transform, 0.0F, 0.0F, 16.0F, 16.0F, 0.5314375F, coverTexture, Direction.SOUTH, color, 1));
                  quads.put(ModelBAItem.Layer.COVER, builder.build());
                  ModelBAItem.BakedDynBlockArmor baked = new ModelBAItem.BakedDynBlockArmor();
                  com.google.common.collect.ImmutableList.Builder<BakedQuad> allQuads = ImmutableList.builder();

                  for (ModelBAItem.Layer layer : ModelBAItem.Layer.values()) {
                     ImmutableList<BakedQuad> layerQuads = quads.get(layer);
                     if (layerQuads == null) {
                        layerQuads = ImmutableList.of();
                     }

                     baked.layers.get(layer).quads = layerQuads;
                     allQuads.addAll(layerQuads);
                  }

                  baked.quads = allQuads.build();
                  baked.particles = sprite;
                  built.put(item, baked);
                  numIcons++;
               }
            }
         }

         ITEM_MODELS.clear();
         ITEM_MODELS.putAll(built);
         return numIcons;
      }

      @Override
      public BakedModel resolve(BakedModel originalModel, ItemStack stack, @Nullable ClientLevel level, @Nullable LivingEntity entity, int num) {
         ModelBAItem.BakedDynBlockArmor model = ITEM_MODELS.get(stack.getItem());
         return model != null ? model : originalModel;
      }
   }

   private static enum Layer {
      BASE,
      TEMPLATE,
      COVER;

      public RenderType getRenderType(ItemStack stack) {
         if (this == COVER) {
            return Sheets.translucentCullBlockSheet();
         } else {
            return Minecraft.useShaderTransparency() ? Sheets.cutoutBlockSheet() : Sheets.translucentItemSheet();
         }
      }
   }

   public static enum LoaderDynBlockArmor implements IModelLoader<ModelBAItem> {
      INSTANCE;

      public void onResourceManagerReload(ResourceManager resourceManager) {
      }

      public ModelBAItem read(JsonDeserializationContext deserializationContext, JsonObject modelContents) {
         return new ModelBAItem();
      }
   }
}
