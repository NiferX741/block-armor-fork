package twopiradians.blockArmor.client.model;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.awt.Color;
import java.lang.reflect.Field;
import java.util.HashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelPart.Cube;
import net.minecraft.client.model.geom.ModelPart.Polygon;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import twopiradians.blockArmor.common.command.CommandDev;
import twopiradians.blockArmor.common.item.BlockArmorItem;

@OnlyIn(Dist.CLIENT)
public class ModelBAArmor<T extends LivingEntity> extends HumanoidModel<T> {
   private static final Field MODEL_BOX_QUADS = ObfuscationReflectionHelper.findField(Cube.class, "f_104341_");
   private static final HashMap<String, ResourceLocation> TEXTURES = Maps.newHashMap();
   private ModelPart offsetHead;
   private ModelPart offsetBody;
   private ModelPart offsetRightArm;
   private ModelPart offsetLeftArm;
   private ModelPart offsetRightLeg;
   private ModelPart offsetLeftLeg;
   private ModelPart offsetWaist;
   private ModelPart offsetRightFoot;
   private ModelPart offsetLeftFoot;
   private ModelPart waist;
   private ModelPart rightFoot;
   private ModelPart leftFoot;
   public int color;
   public float alpha;
   private int textureHeight;
   private int textureWidth;
   private EquipmentSlot slot;
   public LivingEntity entity;
   public int remodelOffset;

   public ModelBAArmor(int textureHeight, int textureWidth, int currentFrame, int nextFrame, EquipmentSlot slot) {
      super(
         new Context(
               Minecraft.getInstance().getEntityRenderDispatcher(),
               Minecraft.getInstance().getItemRenderer(),
               Minecraft.getInstance().getResourceManager(),
               Minecraft.getInstance().getEntityModels(),
               Minecraft.getInstance().font
            )
            .bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)
      );
      int size = Math.max(1, textureWidth / 16);
      this.textureHeight = textureHeight / size;
      this.textureWidth = textureWidth / size;
      this.slot = slot;
      this.waist = new ModelPart(
         Lists.newArrayList(new Cube[]{new Cube(0, 0, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, false, 0.0F, 0.0F)}), Maps.newHashMap()
      );
      this.rightFoot = new ModelPart(
         Lists.newArrayList(new Cube[]{new Cube(0, 0, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, false, 0.0F, 0.0F)}), Maps.newHashMap()
      );
      this.leftFoot = new ModelPart(
         Lists.newArrayList(new Cube[]{new Cube(0, 0, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, true, 0.0F, 0.0F)}), Maps.newHashMap()
      );
      if (currentFrame != nextFrame) {
         this.offsetHead = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetBody = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetRightArm = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetLeftArm = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetRightLeg = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetLeftLeg = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetWaist = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetRightFoot = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.offsetLeftFoot = new ModelPart(Lists.newArrayList(), Maps.newHashMap());
         this.createModel(
            slot,
            textureWidth * nextFrame,
            this.offsetHead,
            this.offsetBody,
            this.offsetRightArm,
            this.offsetLeftArm,
            this.offsetRightLeg,
            this.offsetLeftLeg,
            this.offsetWaist,
            this.offsetRightFoot,
            this.offsetLeftFoot
         );
      }

      this.remodelOffset = textureWidth * currentFrame;
      this.createModel(
         slot,
         textureHeight * currentFrame,
         this.head,
         this.body,
         this.rightArm,
         this.leftArm,
         this.rightLeg,
         this.leftLeg,
         this.waist,
         this.rightFoot,
         this.leftFoot
      );
   }

   private void createModel(
      EquipmentSlot slot,
      int yOffset,
      ModelPart head,
      ModelPart body,
      ModelPart rightArm,
      ModelPart leftArm,
      ModelPart rightLeg,
      ModelPart leftLeg,
      ModelPart waist,
      ModelPart rightFoot,
      ModelPart leftFoot
   ) {
      head.cubes = Lists.newArrayList();
      head.setPos(0.0F, 0.0F, 0.0F);
      body.cubes = Lists.newArrayList();
      body.setPos(0.0F, 0.0F, 0.0F);
      rightArm.cubes = Lists.newArrayList();
      rightArm.setPos(-5.0F, 2.0F, 0.0F);
      leftArm.cubes = Lists.newArrayList();
      leftArm.setPos(5.0F, 2.0F, 0.0F);
      waist.setPos(0.0F, 0.0F, 0.0F);
      rightLeg.cubes = Lists.newArrayList();
      rightLeg.setPos(-1.9F, 12.0F, 0.0F);
      leftLeg.cubes = Lists.newArrayList();
      leftLeg.setPos(1.9F, 12.0F, 0.0F);
      rightFoot.setPos(-1.9F, 12.0F, 0.0F);
      leftFoot.setPos(1.9F, 12.0F, 0.0F);
      switch (slot) {
         case HEAD:
            this.addPlane(head, 9, 3 + yOffset, -5.0F, -9.0F, -5.0F, 10.0F, 0.0F, 10.0F, false);
            this.addPlane(head, 9, 0 + yOffset, -5.0F, -9.0F, 5.0F, 10.0F, 8.0F, 0.0F, true);
            this.addPlane(head, -1, 8 + yOffset, -3.0F, -1.0F, 5.0F, 6.0F, 1.0F, 0.0F, true);
            this.addPlane(head, 6, -10 + yOffset, -5.0F, -9.0F, -5.0F, 0.0F, 5.0F, 10.0F, false);
            this.addPlane(head, 0, 0 + yOffset, -5.0F, -4.0F, -0.0F, 0.0F, 1.0F, 5.0F, false);
            this.addPlane(head, 6, -10 + yOffset, 5.0F, -9.0F, -5.0F, 0.0F, 5.0F, 10.0F, true);
            this.addPlane(head, 11, 0 + yOffset, 5.0F, -4.0F, -0.0F, 0.0F, 1.0F, 5.0F, true);
            this.addPlane(head, 3, 0 + yOffset, -5.0F, -9.0F, -5.0F, 10.0F, 4.0F, 0.0F, false);
            this.addPlane(head, 0, 4 + yOffset, -5.0F, -5.0F, -5.0F, 1.0F, 1.0F, 0.0F, false);
            this.addPlane(head, 7, 4 + yOffset, -1.0F, -5.0F, -5.0F, 2.0F, 2.0F, 0.0F, false);
            this.addPlane(head, 12, 4 + yOffset, 4.0F, -5.0F, -5.0F, 1.0F, 1.0F, 0.0F, false);
            break;
         case CHEST:
            this.addPlane(body, 3, 4 + yOffset, -5.0F, 1.0F, -3.0F, 10.0F, 8.0F, 0.0F, false);
            this.addPlane(body, 4, 12 + yOffset, -4.0F, 9.0F, -3.0F, 8.0F, 1.0F, 0.0F, false);
            this.addPlane(body, 5, 13 + yOffset, -3.0F, 10.0F, -3.0F, 6.0F, 1.0F, 0.0F, false);
            this.addPlane(body, 3, 2 + yOffset, -5.0F, -1.0F, -3.0F, 2.0F, 2.0F, 0.0F, false);
            this.addPlane(body, 5, 2 + yOffset, -3.0F, -0.0F, -3.0F, 1.0F, 1.0F, 0.0F, false);
            this.addPlane(body, 11, 2 + yOffset, 3.0F, -1.0F, -3.0F, 2.0F, 2.0F, 0.0F, false);
            this.addPlane(body, 10, 2 + yOffset, 2.0F, -0.0F, -3.0F, 1.0F, 1.0F, 0.0F, false);
            this.addPlane(body, 5, -4 + yOffset, -5.0F, -1.0F, -3.0F, 0.0F, 10.0F, 6.0F, true);
            this.addPlane(body, -1, -4 + yOffset, 5.0F, -1.0F, -3.0F, 0.0F, 10.0F, 6.0F, false);
            this.addPlane(body, 9, 3 + yOffset, -5.0F, 0.0F, 3.0F, 10.0F, 9.0F, 0.0F, true);
            this.addPlane(body, 11, 2 + yOffset, -5.0F, -1.0F, 3.0F, 2.0F, 0.0F, 0.0F, true);
            this.addPlane(body, 3, 2 + yOffset, 3.0F, -1.0F, 3.0F, 2.0F, 1.0F, 0.0F, true);
            this.addPlane(body, 4, 12 + yOffset, -4.0F, 9.0F, 3.0F, 8.0F, 1.0F, 0.0F, true);
            this.addPlane(rightArm, 5, -4 + yOffset, -4.5F, -3.0F, -3.0F, 0.0F, 6.0F, 6.0F, true);
            this.addPlane(rightArm, 5, -1 + yOffset, 1.5F, -3.0F, -3.0F, 0.0F, 6.0F, 6.0F, true);
            this.addPlane(rightArm, -2, 2 + yOffset, -4.5F, -3.0F, -3.0F, 6.0F, 6.0F, 0.0F, false);
            this.addPlane(rightArm, -8, 2 + yOffset, -4.5F, -3.0F, 3.0F, 6.0F, 6.0F, 0.0F, true);
            this.addPlane(rightArm, 15, 5 + yOffset, -4.5F, -3.0F, -3.0F, 6.0F, 0.0F, 6.0F, false);
            this.addPlane(leftArm, -1, -1 + yOffset, -1.5F, -3.0F, -3.0F, 0.0F, 6.0F, 6.0F, false);
            this.addPlane(leftArm, -1, -4 + yOffset, 4.5F, -3.0F, -3.0F, 0.0F, 6.0F, 6.0F, false);
            this.addPlane(leftArm, 12, 2 + yOffset, -1.5F, -3.0F, -3.0F, 6.0F, 6.0F, 0.0F, false);
            this.addPlane(leftArm, 5, 5 + yOffset, -1.5F, -3.0F, 3.0F, 6.0F, 6.0F, 0.0F, true);
            this.addPlane(leftArm, 15, 5 + yOffset, -1.5F, -3.0F, -3.0F, 6.0F, 0.0F, 6.0F, false);
            break;
         case LEGS:
            this.addPlane(waist, 3, 0 + yOffset, -4.5F, 6.5F, -2.5F, 9.0F, 6.0F, 0.0F, false);
            this.addPlane(waist, 6, -5 + yOffset, -4.5F, 6.5F, -2.5F, 0.0F, 6.0F, 5.0F, false);
            this.addPlane(waist, 6, -5 + yOffset, 4.5F, 6.5F, -2.5F, 0.0F, 6.0F, 5.0F, false);
            this.addPlane(waist, 11, 0 + yOffset, -4.5F, 6.5F, 2.5F, 9.0F, 6.0F, 0.0F, true);
            this.addPlane(rightLeg, 6, 0 + yOffset, -2.5F, -0.5F, -2.5F, 0.0F, 10.0F, 5.0F, false);
            this.addPlane(rightLeg, 9, 5 + yOffset, 2.5F, -0.5F, -2.5F, 0.0F, 10.0F, 5.0F, true);
            this.addPlane(rightLeg, 3, 5 + yOffset, -2.5F, -0.5F, -2.5F, 5.0F, 10.0F, 0.0F, false);
            this.addPlane(rightLeg, -1, 5 + yOffset, -2.5F, -0.5F, 2.5F, 5.0F, 10.0F, 0.0F, true);
            this.addPlane(rightLeg, 9, 0 + yOffset, -2.5F, -0.5F, -2.5F, 5.0F, 0.0F, 5.0F, false);
            this.addPlane(leftLeg, 9, 5 + yOffset, -2.5F, -0.5F, -2.5F, 0.0F, 10.0F, 5.0F, false);
            this.addPlane(leftLeg, 6, 0 + yOffset, 2.5F, -0.5F, -2.5F, 0.0F, 10.0F, 5.0F, false);
            this.addPlane(leftLeg, 7, 5 + yOffset, -2.5F, -0.5F, -2.5F, 5.0F, 10.0F, 0.0F, false);
            this.addPlane(leftLeg, 3, 5 + yOffset, -2.5F, -0.5F, 2.5F, 5.0F, 10.0F, 0.0F, true);
            this.addPlane(leftLeg, 9, 0 + yOffset, -2.5F, -0.5F, -2.5F, 5.0F, 0.0F, 5.0F, false);
            break;
         case FEET:
            this.addPlane(rightFoot, 20, 3 + yOffset, -3.0F, 6.0F, -3.0F, 0.0F, 7.0F, 6.0F, false);
            this.addPlane(rightFoot, 21, 3 + yOffset, 3.0F, 6.0F, -3.0F, 0.0F, 7.0F, 6.0F, true);
            this.addPlane(rightFoot, 2, 7 + yOffset, -3.0F, 6.0F, -3.0F, 6.0F, 7.0F, 0.0F, false);
            this.addPlane(rightFoot, -2, 9 + yOffset, -3.0F, 6.0F, 3.0F, 6.0F, 7.0F, 0.0F, true);
            this.addPlane(rightFoot, -1, 5 + yOffset, -3.0F, 13.0F, -3.0F, 6.0F, 0.0F, 6.0F, false);
            this.addPlane(leftFoot, 21, 3 + yOffset, -3.0F, 6.0F, -3.0F, 0.0F, 7.0F, 6.0F, true);
            this.addPlane(leftFoot, 0, 3 + yOffset, 3.0F, 6.0F, -3.0F, 0.0F, 7.0F, 6.0F, true);
            this.addPlane(leftFoot, -8, 7 + yOffset, -3.0F, 6.0F, -3.0F, 6.0F, 7.0F, 0.0F, false);
            this.addPlane(leftFoot, 0, 9 + yOffset, -3.0F, 6.0F, 3.0F, 6.0F, 7.0F, 0.0F, true);
            this.addPlane(leftFoot, -1, 5 + yOffset, -3.0F, 13.0F, -3.0F, 6.0F, 0.0F, 6.0F, false);
      }
   }

   private void addPlane(
      ModelPart model, int textureOffsetX, int textureOffsetY, float x, float y, float z, float width, float height, float depth, boolean flip
   ) {
      try {
         Cube cube = new Cube(
            textureOffsetX, textureOffsetY, x, y, z, width, height, depth, 0.0F, 0.0F, 0.0F, flip, (float)this.textureWidth, (float)this.textureHeight
         );
         Polygon[] quads = (Polygon[])MODEL_BOX_QUADS.get(cube);
         Polygon[] newQuads = new Polygon[1];
         if (width == 0.0F) {
            newQuads[0] = quads[flip ? 1 : 0];
         } else if (height == 0.0F) {
            newQuads[0] = quads[flip ? 3 : 2];
         } else if (depth == 0.0F) {
            newQuads[0] = quads[flip ? 5 : 4];
         }

         MODEL_BOX_QUADS.set(cube, newQuads);
         model.cubes.add(cube);
      } catch (Exception var14) {
         var14.printStackTrace();
      }
   }

   public void renderToBuffer(
      PoseStack matrix, VertexConsumer vertex, int lightMapUV, int overlayUV, float ageInTicks, float netHeadYaw, float headPitch, float scale
   ) {
      if (this.remodelOffset != -1) {
         this.createModel(
            this.slot,
            this.remodelOffset,
            this.head,
            this.body,
            this.rightArm,
            this.leftArm,
            this.rightLeg,
            this.leftLeg,
            this.waist,
            this.rightFoot,
            this.leftFoot
         );
         this.remodelOffset = -1;
      }

      this.setupAnim((T)this.entity, (float)lightMapUV, (float)overlayUV, ageInTicks, netHeadYaw, headPitch);
      ItemStack stack = this.entity.getItemBySlot(this.slot);
      boolean renderEnchant = false;
      if (stack != null && stack.isEnchanted() && stack.getItem() instanceof BlockArmorItem) {
         ListTag enchantNbt = stack.getEnchantmentTags();

         for (int i = 0; i < enchantNbt.size(); i++) {
            if (!enchantNbt.getCompound(i).getBoolean("blockarmor enchant")) {
               renderEnchant = true;
               break;
            }
         }
      }

      if (stack != null && stack.getItem() instanceof BlockArmorItem) {
         String str = ((BlockArmorItem)stack.getItem()).getArmorTexture(stack, this.entity, this.slot, "");
         ResourceLocation loc = TEXTURES.get(str);
         if (loc == null) {
            loc = new ResourceLocation(str);
            TEXTURES.put(str, loc);
         }

         vertex = Minecraft.getInstance().renderBuffers().bufferSource().getBuffer(RenderType.entityTranslucent(loc));
         this.actualRender(
            matrix,
            vertex,
            false,
            lightMapUV,
            overlayUV,
            ageInTicks,
            netHeadYaw,
            headPitch,
            scale,
            this.head,
            this.body,
            this.rightArm,
            this.leftArm,
            this.rightLeg,
            this.leftLeg,
            this.waist,
            this.rightFoot,
            this.leftFoot
         );
         if (renderEnchant) {
            vertex = Minecraft.getInstance().renderBuffers().bufferSource().getBuffer(RenderType.entityGlintDirect());
            this.actualRender(
               matrix,
               vertex,
               false,
               lightMapUV,
               overlayUV,
               ageInTicks,
               netHeadYaw,
               headPitch,
               scale,
               this.head,
               this.body,
               this.rightArm,
               this.leftArm,
               this.rightLeg,
               this.leftLeg,
               this.waist,
               this.rightFoot,
               this.leftFoot
            );
         }
      }

      if (this.alpha > 0.0F && this.offsetHead != null) {
         this.offsetHead.copyFrom(this.head);
         this.offsetBody.copyFrom(this.body);
         this.offsetRightArm.copyFrom(this.rightArm);
         this.offsetLeftArm.copyFrom(this.leftArm);
         this.offsetRightLeg.copyFrom(this.rightLeg);
         this.offsetLeftLeg.copyFrom(this.leftLeg);
         this.offsetWaist.copyFrom(this.waist);
         this.offsetRightFoot.copyFrom(this.rightFoot);
         this.offsetLeftFoot.copyFrom(this.leftFoot);
         this.actualRender(
            matrix,
            vertex,
            true,
            lightMapUV,
            overlayUV,
            ageInTicks,
            netHeadYaw,
            headPitch,
            scale,
            this.offsetHead,
            this.offsetBody,
            this.offsetRightArm,
            this.offsetLeftArm,
            this.offsetRightLeg,
            this.offsetLeftLeg,
            this.offsetWaist,
            this.offsetRightFoot,
            this.offsetLeftFoot
         );
      }
   }

   private void actualRender(
      PoseStack matrix,
      VertexConsumer vertex,
      boolean animationOverlay,
      int lightMapUV,
      int overlayUV,
      float ageInTicks,
      float netHeadYaw,
      float headPitch,
      float scale,
      ModelPart head,
      ModelPart body,
      ModelPart rightArm,
      ModelPart leftArm,
      ModelPart rightLeg,
      ModelPart leftLeg,
      ModelPart waist,
      ModelPart rightFoot,
      ModelPart leftFoot
   ) {
      float red = 1.0F;
      float green = 1.0F;
      float blue = 1.0F;
      if (this.color != -1) {
         this.color |= -16777216;
         float cb = (float)(this.color & 0xFF);
         float cg = (float)(this.color >>> 8 & 0xFF);
         float cr = (float)(this.color >>> 16 & 0xFF);
         red = cr / 255.0F;
         green = cg / 255.0F;
         blue = cb / 255.0F;
      }

      Float[] color = CommandDev.devColors.get(this.entity.getUUID());
      if (color != null) {
         if (color[0] == 0.0F && color[1] == 0.0F && color[2] == 0.0F) {
            Color color2 = Color.getHSBColor((float)this.entity.tickCount / 30.0F, 1.0F, 1.0F);
            red = (float)color2.getRed() / 255.0F;
            green = (float)color2.getGreen() / 255.0F;
            blue = (float)color2.getBlue() / 255.0F;
         } else {
            double pulse = (Math.cos((double)((float)this.entity.tickCount / 5.0F)) + 1.0) / 3.0 + 0.01;
            red = (float)((double)red + pulse * (double)color[0].floatValue());
            green = (float)((double)green + pulse * (double)color[1].floatValue());
            blue = (float)((double)blue + pulse * (double)color[2].floatValue());
         }
      }

      matrix.pushPose();
      if (this.young) {
         matrix.pushPose();
         float num = 0.75F;
         matrix.scale(num, num, num);
         matrix.translate(0.0, 1.0, 0.0);
         this.head.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         matrix.popPose();
         matrix.pushPose();
         num = 0.5F;
         matrix.scale(num, num, num);
         matrix.translate(0.0, 1.5, 0.0);
         body.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         rightArm.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         leftArm.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         waist.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         rightLeg.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         leftLeg.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         rightFoot.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         leftFoot.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         matrix.popPose();
      } else {
         head.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         body.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         rightArm.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         leftArm.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         waist.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         rightLeg.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         leftLeg.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         rightFoot.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
         leftFoot.render(matrix, vertex, lightMapUV, overlayUV, red, green, blue, animationOverlay ? this.alpha : 1.0F);
      }

      matrix.popPose();
   }

   public void setupAnim(T entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
      this.leftLeg.xRot -= 0.001F;
      this.waist.copyFrom(this.body);
      this.leftFoot.copyFrom(this.leftLeg);
      this.rightFoot.copyFrom(this.rightLeg);
   }
}
