package twopiradians.blockArmor.client.gui;

import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.platform.GlStateManager.DestFactor;
import com.mojang.blaze3d.platform.GlStateManager.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.block.model.ItemTransforms.TransformType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag.Default;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.common.item.BlockArmorItem;
import twopiradians.blockArmor.common.seteffect.SetEffect;

@OnlyIn(Dist.CLIENT)
public class GuiArmorDisplay extends Screen {
   public static final boolean DISPLAY_ARMOR_GUI = false;
   public static final int GUI_MODE = 5;
   public static final int GUI_PAGE = 2;
   private final ResourceLocation backgroundBlue = new ResourceLocation("blockarmor:textures/gui/blue.jpg");
   private final ResourceLocation backgroundWhite = new ResourceLocation("blockarmor:textures/gui/white.png");
   private final ResourceLocation backgroundTooltipColor = new ResourceLocation("blockarmor:textures/gui/tooltip_color.png");
   private EntityGuiPlayer guiPlayer = new EntityGuiPlayer(
      Minecraft.getInstance().level, Minecraft.getInstance().player.getGameProfile(), Minecraft.getInstance().player
   );
   private float partialTicks;
   private ArrayList<BlockArmorItem> armors = new ArrayList<>();
   private Map<TextComponent, ArrayList<ItemStack>> tooltips = new TreeMap<>(new Comparator<TextComponent>() {
      public int compare(TextComponent arg0, TextComponent arg1) {
         return ChatFormatting.stripFormatting(arg0.getString()).compareTo(ChatFormatting.stripFormatting(arg1.getString()));
      }
   });

   public GuiArmorDisplay() {
      super(new TextComponent("Armor Display"));

      for (ArmorSet set : ArmorSet.allSets) {
         if (set.isEnabled()) {
            this.armors.add(set.helmet);
            this.armors.add(set.chestplate);
            this.armors.add(set.leggings);
            this.armors.add(set.boots);
         }

         if (set.isEnabled()) {
            for (SetEffect effect : set.setEffects) {
               if (effect != SetEffect.REGROWTH
                  || !set.registryName.contains("wood")
                     && !set.registryName.contains("stripped")
                     && !set.registryName.contains("spruce")
                     && !set.registryName.contains("birch")
                     && !set.registryName.contains("jungle")
                     && !set.registryName.contains("acacia")
                     && !set.registryName.contains("dark_oak")) {
                  Component tooltip = effect.addInformation(new ItemStack(set.helmet), true, this.guiPlayer, Lists.newArrayList(), Default.NORMAL).get(0);
                  ArrayList<ItemStack> stacks = new ArrayList<>();
                  stacks.add(0, set.getStack());
                  if (this.tooltips.containsKey(tooltip)) {
                     stacks.addAll(0, this.tooltips.get(tooltip));
                  }

                  this.tooltips.put((TextComponent)tooltip, stacks);
               }
            }
         }
      }
   }

   public boolean isPauseScreen() {
      return false;
   }

   public void render(PoseStack matrix, int mouseX, int mouseY, float partialTicks) {
      try {
         this.guiPlayer.setInvisible(false);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.setShaderTexture(0, this.backgroundTooltipColor);
         matrix.pushPose();
         float scale = 1.0F;
         this.blit(matrix, 0, 0, 0, 0, this.width, this.height);
         matrix.popPose();
         int index = 0;

         for (int i = 0; i < this.tooltips.size(); i++) {
            int numStacks = this.tooltips.get(this.tooltips.keySet().toArray(new TextComponent[0])[i]).size();
            int itemsPerRow = numStacks > 10 ? numStacks / 2 + 1 : numStacks;
            float x = 0.0F;
            float y = 0.0F;
            matrix.pushPose();
            float spaceBetween = 49.5F;
            index -= 40;
            if (index >= 0 && index <= 8) {
               x = (float)this.width / 3.8F;
               y = 20.0F + (float)index * spaceBetween;
            } else if (index > 8 && index <= 19) {
               x = (float)this.width / 1.35F;
               y = 155.0F + (float)(index - 10) * spaceBetween;
            } else {
               x = 20035.0F;
               y = 200.0F + (float)(index - 24) * spaceBetween;
            }

            if (numStacks > itemsPerRow) {
               y += 10.0F;
            }

            index += 40;
            List<String> tooltip = new ArrayList<>();
            tooltip.add(((TextComponent[])this.tooltips.keySet().toArray(new TextComponent[0]))[i].getString());
            if (numStacks > itemsPerRow) {
               index += 2;
            } else {
               index++;
            }

            String name = tooltip.get(0).substring(0, tooltip.get(0).indexOf(":"));
            String description = tooltip.get(0).substring(tooltip.get(0).indexOf(":"));
            SetEffect effect = SetEffect.nameToSetEffectMap.get(name);
            if (effect != null) {
               tooltip.set(0, "" + effect.color + ChatFormatting.BOLD + name + ChatFormatting.RESET + effect.color + description);
            }

            if (tooltip.get(0).contains("Regrowth")) {
               tooltip.set(0, "                     " + tooltip.get(0) + "                     ");
            } else if (tooltip.get(0).contains("Invisibility")) {
               tooltip.set(0, "                                 " + tooltip.get(0) + "                                 ");
            } else if (tooltip.get(0).contains("Soft Fall")) {
               tooltip.set(0, "                         " + tooltip.get(0) + "                         ");
            } else if (tooltip.get(0).contains("Falling")) {
               tooltip.set(0, "              " + tooltip.get(0) + "              ");
            } else if (tooltip.get(0).contains("Hoarder") && !tooltip.get(0).contains("Ender")) {
               tooltip.set(0, "                         " + tooltip.get(0) + "                         ");
            } else if (tooltip.get(0).contains("Rocky")) {
               tooltip.set(
                  0,
                  "                                                            "
                     + tooltip.get(0)
                     + "                                                            "
               );
            } else if (tooltip.get(0).contains("Sleepy")) {
               tooltip.set(0, "                        " + tooltip.get(0) + "                        ");
            }

            tooltip.add("");
            tooltip.add("");
            tooltip.add("");
            if (numStacks > itemsPerRow) {
               tooltip.add("");
               tooltip.add("");
               tooltip.add("");
            }

            int length = 0;

            for (String string : tooltip) {
               if (this.font.width(string) > length) {
                  length = this.font.width(string);
               }
            }

            this.renderComponentTooltip(
               matrix, tooltip.stream().map(str -> new TextComponent(str)).collect(Collectors.toList()), (int)x - length / 2, (int)y, this.font
            );
            Lighting.setupFor3DItems();
            length = numStacks * 20;
            scale = 1.6F;

            for (int j = 0; j < numStacks; j++) {
               int rowSize = j > itemsPerRow ? numStacks % itemsPerRow + 1 : Math.min(numStacks, itemsPerRow);
               int k = j > itemsPerRow ? (rowSize == 0 ? 0 : j % (rowSize + 0)) + 0 : j;
               spaceBetween = (float)(26 - (rowSize - 1) / 5);
               this.itemRenderer.blitOffset = 500.0F;
               ItemStack stack = this.tooltips.get(this.tooltips.keySet().toArray(new TextComponent[0])[i]).get(j);
               if (j > itemsPerRow) {
                  this.renderGuiItem(stack, (int)(x + 2.0F + ((float)k * spaceBetween - (float)(rowSize - 1) * spaceBetween / 2.0F)), (int)y + 32, scale);
               } else {
                  this.renderGuiItem(
                     stack,
                     (int)(x + 2.0F + ((float)k * spaceBetween - (float)(rowSize - (numStacks > itemsPerRow ? 0 : 1)) * spaceBetween / 2.0F)),
                     (int)y + 5,
                     scale
                  );
               }
            }

            Lighting.setupForFlatItems();
            matrix.popPose();
         }
      } catch (Exception var22) {
         var22.printStackTrace();
      }

      super.render(matrix, mouseX, mouseY, partialTicks);
   }

   private ArrayList<Component> addStatTooltips(ArrayList<Component> tooltip, ItemStack[] armor) {
      ArrayList<Multimap<Attribute, AttributeModifier>> list = new ArrayList<>();
      list.add(armor[0].getAttributeModifiers(EquipmentSlot.HEAD));
      list.add(armor[1].getAttributeModifiers(EquipmentSlot.CHEST));
      list.add(armor[2].getAttributeModifiers(EquipmentSlot.LEGS));
      list.add(armor[3].getAttributeModifiers(EquipmentSlot.FEET));
      if (armor[3].hasTag()) {
         ListTag nbttaglist = armor[3].getEnchantmentTags();
         if (nbttaglist != null) {
            for (int j = 0; j < nbttaglist.size(); j++) {
               int k = nbttaglist.getCompound(j).getShort("id");
               int l = nbttaglist.getCompound(j).getShort("lvl");
               if (Enchantment.byId(k) != null) {
                  tooltip.add(new TextComponent(ChatFormatting.GRAY + Enchantment.byId(k).getFullname(l).getString()));
               }
            }
         }
      }

      for (ItemStack stack : armor) {
         int i = 0;

         for (EquipmentSlot equipmentslottype : EquipmentSlot.values()) {
            Multimap<Attribute, AttributeModifier> multimap = stack.getAttributeModifiers(equipmentslottype);
            if (!multimap.isEmpty()) {
               tooltip.add(TextComponent.EMPTY);
               tooltip.add(new TranslatableComponent("item.modifiers." + equipmentslottype.getName()).withStyle(ChatFormatting.GRAY));

               for (Entry<Attribute, AttributeModifier> entry : multimap.entries()) {
                  AttributeModifier attributemodifier = entry.getValue();
                  double d0 = attributemodifier.getAmount();
                  boolean flag = false;
                  if (this.guiPlayer != null) {
                     if (attributemodifier.getId() == SetEffect.ATTACK_DAMAGE_UUID) {
                        d0 += this.guiPlayer.getAttributeBaseValue(Attributes.ATTACK_DAMAGE);
                        d0 += (double)EnchantmentHelper.getDamageBonus(stack, MobType.UNDEFINED);
                        flag = true;
                     } else if (attributemodifier.getId() == SetEffect.ATTACK_SPEED_UUID) {
                        d0 += this.guiPlayer.getAttributeBaseValue(Attributes.ATTACK_SPEED);
                        flag = true;
                     }
                  }

                  double d1;
                  if (attributemodifier.getOperation() == Operation.MULTIPLY_BASE || attributemodifier.getOperation() == Operation.MULTIPLY_TOTAL) {
                     d1 = d0 * 100.0;
                  } else if (entry.getKey().equals(Attributes.KNOCKBACK_RESISTANCE)) {
                     d1 = d0 * 10.0;
                  } else {
                     d1 = d0;
                  }

                  if (flag) {
                     tooltip.add(
                        new TextComponent(" ")
                           .append(
                              new TranslatableComponent(
                                 "attribute.modifier.equals." + attributemodifier.getOperation().toValue(),
                                 new Object[]{ItemStack.ATTRIBUTE_MODIFIER_FORMAT.format(d1), new TranslatableComponent(entry.getKey().getDescriptionId())}
                              )
                           )
                           .withStyle(ChatFormatting.DARK_GREEN)
                     );
                  } else if (d0 > 0.0) {
                     tooltip.add(
                        new TranslatableComponent(
                              "attribute.modifier.plus." + attributemodifier.getOperation().toValue(),
                              new Object[]{ItemStack.ATTRIBUTE_MODIFIER_FORMAT.format(d1), new TranslatableComponent(entry.getKey().getDescriptionId())}
                           )
                           .withStyle(ChatFormatting.BLUE)
                     );
                  } else if (d0 < 0.0) {
                     d1 *= -1.0;
                     tooltip.add(
                        new TranslatableComponent(
                              "attribute.modifier.take." + attributemodifier.getOperation().toValue(),
                              new Object[]{ItemStack.ATTRIBUTE_MODIFIER_FORMAT.format(d1), new TranslatableComponent(entry.getKey().getDescriptionId())}
                           )
                           .withStyle(ChatFormatting.RED)
                     );
                  }
               }
            }
         }
      }

      return tooltip;
   }

   public void renderGuiItem(ItemStack p_115124_, int p_115125_, int p_115126_, float scale) {
      this.renderGuiItem(
         p_115124_, p_115125_, p_115126_, Minecraft.getInstance().getItemRenderer().getModel(p_115124_, (Level)null, (LivingEntity)null, 0), scale
      );
   }

   protected void renderGuiItem(ItemStack stack, int x, int y, BakedModel model, float scale) {
      Minecraft.getInstance().getTextureManager().getTexture(TextureAtlas.LOCATION_BLOCKS).setFilter(false, false);
      RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_BLOCKS);
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      PoseStack posestack = RenderSystem.getModelViewStack();
      posestack.pushPose();
      posestack.translate((double)x, (double)y, (double)(100.0F + Minecraft.getInstance().getItemRenderer().blitOffset));
      posestack.translate(8.0, 8.0, 0.0);
      posestack.scale(1.0F, -1.0F, 1.0F);
      posestack.scale(16.0F, 16.0F, 16.0F);
      posestack.scale(scale, scale, scale);
      RenderSystem.applyModelViewMatrix();
      PoseStack posestack1 = new PoseStack();
      BufferSource multibuffersource$buffersource = Minecraft.getInstance().renderBuffers().bufferSource();
      boolean flag = !model.usesBlockLight();
      if (flag) {
         Lighting.setupForFlatItems();
      }

      for (int i = 0; i < 1; i++) {
         posestack1.pushPose();
         posestack1.scale(1.1F, 1.1F, 1.1F);
         posestack1.translate(0.0, 0.0, -1.0);
         Minecraft.getInstance()
            .getItemRenderer()
            .render(stack, TransformType.GUI, false, posestack1, multibuffersource$buffersource, 15728880, OverlayTexture.pack(8, 10), model);
         multibuffersource$buffersource.endBatch();
         posestack1.popPose();
      }

      Minecraft.getInstance()
         .getItemRenderer()
         .render(stack, TransformType.GUI, false, posestack1, multibuffersource$buffersource, 15728880, OverlayTexture.NO_OVERLAY, model);
      multibuffersource$buffersource.endBatch();
      RenderSystem.enableDepthTest();
      if (flag) {
         Lighting.setupFor3DItems();
      }

      posestack.popPose();
      RenderSystem.applyModelViewMatrix();
   }
}
