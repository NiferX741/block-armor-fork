package twopiradians.blockArmor.common;

import com.google.common.collect.Maps;
import java.util.HashMap;
import java.util.UUID;
import net.minecraft.world.entity.player.Player;

/** Tracks whether a player is holding the set-effect key. Safe to load on a dedicated server. */
public class SetEffectKey {
   public final HashMap<UUID, Boolean> isKeyDown = Maps.newHashMap();

   public boolean isKeyDown(Player player) {
      if (player == null) {
         return false;
      }

      Boolean keyDown = this.isKeyDown.get(player.getUUID());
      return keyDown != null && keyDown;
   }
}
