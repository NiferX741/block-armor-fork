package twopiradians.blockArmor.common;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.NetworkRegistry.ChannelBuilder;
import net.minecraftforge.network.simple.SimpleChannel;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import twopiradians.blockArmor.client.ClientProxy;

@Mod("blockarmor")
@EventBusSubscriber(
   bus = Bus.MOD
)
public class BlockArmor {
   public static final String MODNAME = "Block Armor";
   public static final String MODID = "blockarmor";
   public static final Logger LOGGER = LogManager.getLogger("blockarmor");
   public static final SimpleChannel NETWORK = ChannelBuilder.named(new ResourceLocation("blockarmor", "main_channel"))
      .clientAcceptedVersions(NetworkRegistry.ABSENT::equals)
      .serverAcceptedVersions(NetworkRegistry.ABSENT::equals)
      .networkProtocolVersion(() -> NetworkRegistry.ABSENT)
      .simpleChannel();
   public static final SetEffectKey key = new SetEffectKey();

   public BlockArmor() {
      CommonProxy.LOOT_MODIFIERS.register(FMLJavaModLoadingContext.get().getModEventBus());
   }

   @SubscribeEvent
   public static void onCommonSetupEvent(FMLCommonSetupEvent event) {
      event.enqueueWork(CommonProxy::setup);
   }

   @SubscribeEvent
   public static void onClientSetupEvent(FMLClientSetupEvent event) {
      event.enqueueWork(ClientProxy::setup);
   }
}
