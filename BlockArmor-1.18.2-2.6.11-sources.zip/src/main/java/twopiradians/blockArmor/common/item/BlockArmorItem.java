package twopiradians.blockArmor.common.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.IItemRenderProperties;
import twopiradians.blockArmor.client.ClientProxy;
import twopiradians.blockArmor.client.model.ModelBAArmor;
import twopiradians.blockArmor.common.command.CommandDev;
import twopiradians.blockArmor.common.config.Config;
import twopiradians.blockArmor.common.seteffect.SetEffect;

public class BlockArmorItem extends ArmorItem {
   private static final UUID[] ARMOR_MODIFIERS = new UUID[]{
      UUID.fromString("845DB27C-C624-495F-8C9F-6020A9A58B6B"),
      UUID.fromString("D8499B04-0E66-4726-AB29-64469D734E0D"),
      UUID.fromString("9F3D476D-C118-4544-8365-64846904B48E"),
      UUID.fromString("2AD3F246-FEE1-4E67-B886-69FD380BB150")
   };
   public ArmorSet set;
   @Nullable
   public CreativeModeTab group;
   private ArmorMaterial material;
   private HashMultimap<Attribute, AttributeModifier> attributes;

   public BlockArmorItem(BlockArmorMaterial material, EquipmentSlot slot, ArmorSet set) {
      super(material, slot, new Properties().tab(CreativeModeTab.TAB_COMBAT));
      this.set = set;
      this.setMaterial(material);
   }

   @OnlyIn(Dist.CLIENT)
   public String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot, String type) {
      TextureAtlasSprite sprite = this.set.getTextureInfo(slot).sprite;
      String texture = sprite.getName() + ".png";
      int index = texture.indexOf(":");
      return texture.substring(0, index + 1) + "textures/" + texture.substring(index + 1);
   }

   @OnlyIn(Dist.CLIENT)
   public void initializeClient(Consumer<IItemRenderProperties> consumer) {
      consumer.accept(new IItemRenderProperties() {
         @OnlyIn(Dist.CLIENT)
         public HumanoidModel<?> getArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot armorSlot, HumanoidModel<?> _default) {
            BlockArmorItem item = (BlockArmorItem)stack.getItem();
            TextureInfo info = item.set.getTextureInfo(item.slot);
            TextureAtlasSprite sprite = info.sprite;
            int width = sprite.getWidth();
            int height = info.originalHeight;
            int currentFrame = info.getCurrentAnimationFrame();
            int nextFrame = info.getNextAnimationFrame();
            ModelBAArmor model = (ModelBAArmor)ClientProxy.getBlockArmorModel(entity, height, width, currentFrame, nextFrame, BlockArmorItem.this.slot);
            model.color = info.color;
            model.alpha = info.getAlpha();
            return model;
         }
      });
   }

   public void fillItemCategory(CreativeModeTab group, NonNullList<ItemStack> items) {
      if (this.set.isEnabled()) {
         super.fillItemCategory(group, items);
      }
   }

   protected boolean allowdedIn(CreativeModeTab group) {
      return this.set.isEnabled() && group != null && (group == CreativeModeTab.TAB_SEARCH || group == this.group);
   }

   public void setGroup(CreativeModeTab group) {
      this.group = group;
   }

   public void setDamage(ItemStack stack, int damage) {
      stack.getOrCreateTag().putInt("Damage", Math.max(0, damage));
      if (damage >= this.getMaxDamage(stack) && this.set.setEffects.contains(SetEffect.HOARDER)) {
         SetEffect.HOARDER.onBreak(stack);
      }
   }

   public Component getName(ItemStack stack) {
      return ArmorSet.getItemStackDisplayName(stack.getItem(), this.getSlot());
   }

   public Multimap<Attribute, AttributeModifier> getAttributeModifiers(EquipmentSlot slot, ItemStack stack) {
      Multimap<Attribute, AttributeModifier> map = slot == this.slot ? HashMultimap.create(this.attributes) : HashMultimap.create();
      if (slot != this.slot) {
         return map;
      } else {
         for (SetEffect effect : this.set.setEffects) {
            map = effect.getAttributeModifiers(map, slot, stack);
         }

         return map;
      }
   }

   public Rarity getRarity(ItemStack stack) {
      if (stack.isEnchanted()) {
         return Rarity.RARE;
      } else {
         return !this.set.setEffects.isEmpty() ? Rarity.UNCOMMON : Rarity.COMMON;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public void appendHoverText(ItemStack stack, @Nullable Level worldIn, List<Component> tooltip, TooltipFlag flagIn) {
      if (stack.hasTag() && stack.getTag().contains("devSpawned")) {
         tooltip.add(new TextComponent("" + ChatFormatting.DARK_PURPLE + ChatFormatting.BOLD + "Dev Spawned"));
      }

      if (!this.set.setEffects.isEmpty() && this.set.setEffects.get(0).isEnabled()) {
         if (Screen.hasShiftDown()) {
            tooltip.add(
               new TranslatableComponent(
                     "item.blockarmor.tooltip.setEffects",
                     new Object[]{
                        new TranslatableComponent(
                              "item.blockarmor.tooltip.setEffectsRequire" + (Config.piecesForSet == 4 ? "" : "+"), new Object[]{Config.piecesForSet}
                           )
                           .withStyle(ChatFormatting.ITALIC),
                        Config.piecesForSet
                     }
                  )
                  .withStyle(ChatFormatting.GOLD)
            );
         }

         for (SetEffect effect : this.set.setEffects) {
            if (effect.isEnabled()) {
               tooltip = effect.addInformation(stack, Screen.hasShiftDown(), Minecraft.getInstance().player, tooltip, flagIn);
            }
         }
      }
   }

   public void inventoryTick(ItemStack stack, Level world, Entity entity, int itemSlot, boolean isSelected) {
      if (!stack.isEmpty()
         && (this.set.isEnabled() || !(!world.isClientSide & entity instanceof Player))
         && (
            world.isClientSide
               || !(entity instanceof Player)
               || !stack.hasTag()
               || !stack.getTag().contains("devSpawned")
               || CommandDev.DEVS.contains(entity.getUUID())
         )) {
         if (!stack.hasTag()) {
            stack.setTag(new CompoundTag());
         }

         for (SetEffect effect : this.set.setEffects) {
            effect.onUpdate(stack, world, entity, this.slot.getFilterFlag(), isSelected);
         }
      } else {
         if (((Player)entity).getInventory().getItem(itemSlot) == stack) {
            ((Player)entity).getInventory().setItem(itemSlot, ItemStack.EMPTY);
         }
      }
   }

   public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entityItem) {
      if ((this.set.isEnabled() || entityItem.level.isClientSide)
         && (
            entityItem.level.isClientSide
               || entityItem == null
               || entityItem.getItem() == null
               || !entityItem.getItem().hasTag()
               || !entityItem.getItem().getTag().contains("devSpawned")
         )) {
         return false;
      } else {
         entityItem.discard();
         return true;
      }
   }

   public void onArmorTick(ItemStack stack, Level world, Player player) {
      if (!stack.isEmpty()
         && (this.set.isEnabled() || world.isClientSide)
         && (
            world.isClientSide
               || stack == null
               || !stack.hasTag()
               || !stack.getTag().contains("devSpawned")
               || CommandDev.DEVS.contains(player.getUUID())
               || player.getItemBySlot(this.slot) != stack
         )) {
         if (!stack.hasTag()) {
            stack.setTag(new CompoundTag());
         }

         for (SetEffect effect : this.set.setEffects) {
            if (ArmorSet.getWornSetEffects(player).contains(effect)) {
               effect.onArmorTick(world, player, stack);
            }
         }
      } else {
         player.setItemSlot(this.slot, ItemStack.EMPTY);
      }
   }

   public void setMaterial(ArmorMaterial material) {
      this.material = material;
      this.attributes = HashMultimap.create();
      UUID uuid = ARMOR_MODIFIERS[this.slot.getIndex()];
      this.attributes.put(Attributes.ARMOR, new AttributeModifier(uuid, "Armor modifier", (double)this.getDefense(), Operation.ADDITION));
      this.attributes.put(Attributes.ARMOR_TOUGHNESS, new AttributeModifier(uuid, "Armor toughness", (double)this.getToughness(), Operation.ADDITION));
      if (this.material.getKnockbackResistance() > 0.0F) {
         this.attributes
            .put(
               Attributes.KNOCKBACK_RESISTANCE,
               new AttributeModifier(
                  uuid,
                  "Armor knockback resistance",
                  (double)this.material.getKnockbackResistance() / 10.0 * Config.globalKnockbackResistanceModifier,
                  Operation.ADDITION
               )
            );
      }

      this.maxDamage = (int)((double)material.getDurabilityForSlot(this.slot) * Config.globalDurabilityModifier);
   }

   public ArmorMaterial getMaterial() {
      return this.material;
   }

   public int getDefense() {
      return (int)((double)this.material.getDefenseForSlot(this.slot) * Config.globalDamageReductionModifier);
   }

   public float getToughness() {
      return (float)((double)this.material.getToughness() * Config.globalToughnessModifier);
   }

   public int getEnchantmentValue() {
      return (int)((double)this.material.getEnchantmentValue() * Config.globalEnchantabilityModifier);
   }
}
