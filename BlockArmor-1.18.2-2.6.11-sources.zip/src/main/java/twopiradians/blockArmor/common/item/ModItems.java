package twopiradians.blockArmor.common.item;

import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.config.ModConfig.Type;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.ForgeRegistry;
import net.minecraftforge.registries.IForgeRegistry;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.config.Config;
import twopiradians.blockArmor.common.seteffect.SetEffect;

public class ModItems {
   public static ArrayList<BlockArmorItem> allArmors = new ArrayList<>();

   private static BlockArmorItem register(IForgeRegistry<Item> registry, BlockArmorItem armor, String itemName) {
      allArmors.add(armor);
      armor.setRegistryName("blockarmor", itemName);
      registry.register(armor);
      return armor;
   }

   public static void registerRenders() {
      for (BlockArmorItem item : allArmors) {
         Minecraft.getInstance().getItemRenderer().getItemModelShaper().register(item, new ModelResourceLocation(item.getRegistryName(), "inventory"));
      }
   }

   @EventBusSubscriber(
      bus = Bus.MOD
   )
   public static class RegistrationHandler {
      @SubscribeEvent(
         priority = EventPriority.LOWEST
      )
      public static void registerItems(Register<VillagerProfession> event) {
         ForgeRegistry registry = (ForgeRegistry)ForgeRegistries.ITEMS;
         registry.unfreeze();
         ArmorSet.setup(registry.getValues());
         SetEffect.setup();
         ModLoadingContext.get().registerConfig(Type.SERVER, Config.init());
         int vanillaItems = 0;
         int moddedItems = 0;

         for (ArmorSet set : ArmorSet.allSets) {
            String registryName = ArmorSet.getItemRegistryName(set.item);
            set.helmet = ModItems.register(registry, new BlockArmorItem(set.material, EquipmentSlot.HEAD, set), registryName + "_helmet");
            set.chestplate = ModItems.register(registry, new BlockArmorItem(set.material, EquipmentSlot.CHEST, set), registryName + "_chestplate");
            set.leggings = ModItems.register(registry, new BlockArmorItem(set.material, EquipmentSlot.LEGS, set), registryName + "_leggings");
            set.boots = ModItems.register(registry, new BlockArmorItem(set.material, EquipmentSlot.FEET, set), registryName + "_boots");
            if (set.isFromModdedBlock) {
               moddedItems += 4;
            } else {
               vanillaItems += 4;
            }

            set.enable();
         }

         BlockArmor.LOGGER.info("Generated " + vanillaItems + " Block Armor items from Vanilla blocks");
         if (moddedItems > 0) {
            BlockArmor.LOGGER.info("Generated " + moddedItems + " Block Armor items from Modded blocks");
         }

         registry.freeze();
      }
   }
}
