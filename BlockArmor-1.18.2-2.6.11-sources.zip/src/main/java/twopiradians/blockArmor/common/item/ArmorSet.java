package twopiradians.blockArmor.common.item;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureAtlasSprite.AnimatedTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Tuple;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.InfestedBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.OreBlock;
import net.minecraft.world.level.block.RedstoneLampBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent.ClientTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.ServerTickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.server.ServerLifecycleHooks;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.command.CommandDev;
import twopiradians.blockArmor.common.config.Config;
import twopiradians.blockArmor.common.seteffect.SetEffect;
import twopiradians.blockArmor.creativetab.BlockArmorCreativeTab;
import twopiradians.blockArmor.utils.BlockUtils;

@EventBusSubscriber
public class ArmorSet {
   private static final ArrayList<Block> MANUALLY_ADDED_SETS = new ArrayList<Block>() {
      {
         this.add(Blocks.SUGAR_CANE);
         this.add(Blocks.CACTUS);
         this.add(Blocks.DISPENSER);
         this.add(Blocks.DROPPER);
         this.add(Blocks.BEACON);
         this.add(Blocks.FURNACE);
         this.add(Blocks.ENCHANTING_TABLE);
         this.add(Blocks.COMMAND_BLOCK);
         this.add(Blocks.CHAIN_COMMAND_BLOCK);
         this.add(Blocks.REPEATING_COMMAND_BLOCK);
         this.add(Blocks.BROWN_MUSHROOM_BLOCK);
         this.add(Blocks.RED_MUSHROOM_BLOCK);
         this.add(Blocks.SOUL_SAND);
         this.add(Blocks.ENDER_CHEST);
         this.add(Blocks.BLAST_FURNACE);
         this.add(Blocks.COMPOSTER);
         this.add(Blocks.SMOKER);
         this.add(Blocks.BEE_NEST);
         this.add(Blocks.BEEHIVE);
         this.add(Blocks.BARREL);
         this.add(Blocks.HONEY_BLOCK);
         this.add(Blocks.CHEST);
         this.add(Blocks.NOTE_BLOCK);
         this.add(Blocks.JUKEBOX);
      }
   };
   public static final EquipmentSlot[] SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   public static final HashMap<Block, TextureOverrideInfo> TEXTURE_OVERRIDES = new HashMap<Block, TextureOverrideInfo>() {
      {
         TextureOverrideInfo info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.CHEST, -1, new ResourceLocation("blockarmor", "items/overrides/enchanting_table_chest"));
         info.addSlot(EquipmentSlot.LEGS, -1, new ResourceLocation("blockarmor", "items/overrides/enchanting_table_legs"));
         this.put(Blocks.ENCHANTING_TABLE, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/cactus_head"));
         info.addSlot(EquipmentSlot.CHEST, -1, new ResourceLocation("blockarmor", "items/overrides/cactus_chest"));
         info.addSlot(EquipmentSlot.LEGS, -1, new ResourceLocation("blockarmor", "items/overrides/cactus_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/cactus_feet"));
         this.put(Blocks.CACTUS, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/sugar_cane_head"));
         info.addSlot(EquipmentSlot.CHEST, -1, new ResourceLocation("blockarmor", "items/overrides/sugar_cane_chest"));
         info.addSlot(EquipmentSlot.LEGS, -1, new ResourceLocation("blockarmor", "items/overrides/sugar_cane_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/sugar_cane_feet"));
         this.put(Blocks.SUGAR_CANE, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/ender_chest_head"));
         info.addSlot(EquipmentSlot.CHEST, -1, new ResourceLocation("blockarmor", "items/overrides/ender_chest_chest"));
         info.addSlot(EquipmentSlot.LEGS, -1, new ResourceLocation("blockarmor", "items/overrides/ender_chest_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/ender_chest_feet"));
         this.put(Blocks.ENDER_CHEST, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/chest_head"));
         info.addSlot(EquipmentSlot.CHEST, -1, new ResourceLocation("blockarmor", "items/overrides/chest_chest"));
         info.addSlot(EquipmentSlot.LEGS, -1, new ResourceLocation("blockarmor", "items/overrides/chest_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/chest_feet"));
         this.put(Blocks.CHEST, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/composter_head"));
         this.put(Blocks.COMPOSTER, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/shulker_box_head"));
         info.addSlot(EquipmentSlot.CHEST, -1, new ResourceLocation("blockarmor", "items/overrides/shulker_box_chest"));
         info.addSlot(EquipmentSlot.LEGS, -1, new ResourceLocation("blockarmor", "items/overrides/shulker_box_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/shulker_box_feet"));
         this.put(Blocks.SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.WHITE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.WHITE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.WHITE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.WHITE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.WHITE_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.ORANGE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.ORANGE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.ORANGE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.ORANGE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.ORANGE_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.MAGENTA_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.MAGENTA_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.MAGENTA_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.MAGENTA_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.MAGENTA_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.LIGHT_BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.LIGHT_BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.LIGHT_BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.LIGHT_BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.LIGHT_BLUE_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.YELLOW_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.YELLOW_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.YELLOW_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.YELLOW_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.YELLOW_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.LIME_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.LIME_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.LIME_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.LIME_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.LIME_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.PINK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.PINK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.PINK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.PINK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.PINK_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.GRAY_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.LIGHT_GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.LIGHT_GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.LIGHT_GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.LIGHT_GRAY_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.LIGHT_GRAY_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.CYAN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.CYAN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.CYAN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.CYAN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.CYAN_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.PURPLE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.PURPLE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.PURPLE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.PURPLE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.PURPLE_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.BLUE_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.BLUE_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.BROWN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.BROWN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.BROWN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.BROWN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.BROWN_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.GREEN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.GREEN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.GREEN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.GREEN_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.GREEN_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.RED_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.RED_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.RED_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.RED_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.RED_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(
            EquipmentSlot.HEAD,
            ((ShulkerBoxBlock)Blocks.BLACK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_head")
         );
         info.addSlot(
            EquipmentSlot.CHEST,
            ((ShulkerBoxBlock)Blocks.BLACK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_chest")
         );
         info.addSlot(
            EquipmentSlot.LEGS,
            ((ShulkerBoxBlock)Blocks.BLACK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_legs")
         );
         info.addSlot(
            EquipmentSlot.FEET,
            ((ShulkerBoxBlock)Blocks.BLACK_SHULKER_BOX).getColor().getFireworkColor(),
            new ResourceLocation("blockarmor", "items/overrides/white_shulker_box_feet")
         );
         this.put(Blocks.BLACK_SHULKER_BOX, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.WHITE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.WHITE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.WHITE_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.ORANGE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.ORANGE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.ORANGE_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.MAGENTA.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.MAGENTA.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.MAGENTA_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.LIGHT_BLUE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.LIGHT_BLUE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.LIGHT_BLUE_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.YELLOW.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.YELLOW.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.YELLOW_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.LIME.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.LIME.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.LIME_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.PINK.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.PINK.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.PINK_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.GRAY.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.GRAY.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.GRAY_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.LIGHT_GRAY.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.LIGHT_GRAY.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.LIGHT_GRAY_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.CYAN.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.CYAN.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.CYAN_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.PURPLE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.PURPLE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.PURPLE_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.BLUE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.BLUE.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.BLUE_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.BROWN.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.BROWN.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.BROWN_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.GREEN.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.GREEN.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.GREEN_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.RED.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.RED.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.RED_BED, info);
         info = new TextureOverrideInfo();
         info.addSlot(EquipmentSlot.HEAD, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_head"));
         info.addSlot(EquipmentSlot.CHEST, DyeColor.BLACK.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_chest"));
         info.addSlot(EquipmentSlot.LEGS, DyeColor.BLACK.getFireworkColor(), new ResourceLocation("blockarmor", "items/overrides/white_bed_legs"));
         info.addSlot(EquipmentSlot.FEET, -1, new ResourceLocation("blockarmor", "items/overrides/white_bed_feet"));
         this.put(Blocks.BLACK_BED, info);
      }
   };
   public static ArrayList<ArmorSet> allSets = Lists.newArrayList();
   public static HashMap<String, ArmorSet> nameToSetMap = Maps.newHashMap();
   public static HashMap<String, TreeSet<ArmorSet>> modidToSetMap = Maps.newHashMap();
   @OnlyIn(Dist.CLIENT)
   public static TextureAtlasSprite missingSprite;
   private static HashMap<UUID, HashSet<SetEffect>> playerSetEffectsClient = Maps.newHashMap();
   private static HashMap<UUID, HashSet<SetEffect>> playerSetEffectsServer = Maps.newHashMap();
   @Nullable
   private ItemStack stack;
   public Item item;
   public Block block;
   public BlockArmorMaterial material;
   public BlockArmorItem helmet;
   public BlockArmorItem chestplate;
   public BlockArmorItem leggings;
   public BlockArmorItem boots;
   public boolean isFromModdedBlock;
   public ArrayList<SetEffect> setEffects;
   public ArrayList<SetEffect> defaultSetEffects;
   public String modid;
   public String registryName;
   private boolean enabled;
   public boolean missingTextures;
   @OnlyIn(Dist.CLIENT)
   private HashMap<EquipmentSlot, TextureInfo> textureInfo;
   public float armorDamageReduction;
   public float armorToughness;
   public int armorDurability;
   public int armorEnchantability;
   public int armorKnockbackResistance;

   public ArmorSet(Item item) {
      this.item = item.asItem();
      this.block = ((BlockItem)item).getBlock();
      this.registryName = getItemRegistryName(this.item);

      try {
         ResourceLocation loc = this.item.getRegistryName();
         this.modid = loc.getNamespace().toLowerCase();
         if (!this.modid.equals("minecraft")) {
            this.isFromModdedBlock = true;
         }
      } catch (Exception var7) {
         this.modid = "???";
         this.isFromModdedBlock = true;
      }

      boolean indestructible = BlockUtils.getHardness(this.block) == -1.0F;
      float hardness = Math.min(BlockUtils.getHardness(this.block), 100.0F);
      if (indestructible) {
         hardness = 100.0F;
      }

      float blastResistance = BlockUtils.getBlastResistance(this.block);
      boolean requiresTool = BlockUtils.getRequiresTool(this.block);
      boolean isSolid = BlockUtils.getIsSolid(this.block);
      this.armorDamageReduction = hardness >= 8.0F ? hardness * 0.003F + 4.5F : hardness * 0.65F;
      if (requiresTool) {
         this.armorDamageReduction *= 1.2F;
      }

      if (!isSolid) {
         this.armorDamageReduction *= 0.5F;
      }

      if (indestructible) {
         this.armorDamageReduction *= 20.0F;
      }

      this.armorDamageReduction = Math.max(this.armorDamageReduction * 0.6F, 1.0F);
      this.armorDurability = (int)(indestructible ? 0.0F : Math.min(30.0F, this.armorDamageReduction * 8.0F));
      this.armorToughness = Math.min(20.0F, blastResistance > 100.0F ? blastResistance / 400.0F : 0.0F);
      this.armorEnchantability = 12;
      this.armorKnockbackResistance = 0;
      this.createMaterial();
      CommandDev.addBlockName(this);
   }

   public void createMaterial() {
      int[] reductionAmounts = new int[]{
         (int)this.armorDamageReduction,
         (int)(this.armorDamageReduction * 2.0F),
         (int)(this.armorDamageReduction * 2.5F),
         (int)(this.armorDamageReduction * 1.45F)
      };
      this.material = new BlockArmorMaterial(
         getItemStackDisplayName(this.item, null) + " Material",
         this.armorDurability,
         reductionAmounts,
         this.armorEnchantability,
         SoundEvents.ARMOR_EQUIP_GENERIC,
         this.armorToughness,
         (float)this.armorKnockbackResistance,
         () -> Ingredient.of(new ItemLike[]{this.item})
      );

      for (EquipmentSlot slot : SLOTS) {
         BlockArmorItem armor = this.getArmorForSlot(slot);
         if (armor != null) {
            armor.setMaterial(this.material);
         }
      }
   }

   public ItemStack getStack() {
      if (this.stack == null) {
         this.stack = new ItemStack(this.block);
      }

      return this.stack;
   }

   public BlockArmorItem getArmorForSlot(EquipmentSlot slot) {
      switch (slot) {
         case HEAD:
            return this.helmet;
         case CHEST:
            return this.chestplate;
         case LEGS:
            return this.leggings;
         case FEET:
            return this.boots;
         default:
            return null;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public TextureInfo getTextureInfo(EquipmentSlot slot) {
      if (this.textureInfo == null) {
         this.initTextures();
      }

      return this.textureInfo.get(slot);
   }

   public static void setup(Collection<Item> itemsIn) {
      ArrayList<String> displayNames = new ArrayList<>();
      ArrayList<Item> items = new ArrayList<>();

      for (Item item : itemsIn) {
         try {
            if (item instanceof BlockItem) {
               Block block = ((BlockItem)item).getBlock();
               boolean manuallyAdded = false;

               for (Block manualBlock : MANUALLY_ADDED_SETS) {
                  if (block == manualBlock) {
                     manuallyAdded = true;
                  }
               }

               String displayName = getNormalDisplayName(item);
               if (manuallyAdded || !displayName.isEmpty() && !displayNames.contains(displayName)) {
                  items.add(item);
                  displayNames.add(displayName);
               }
            }
         } catch (Exception var10) {
         }
      }

      ArrayList<String> registryNames = new ArrayList<>();
      allSets = new ArrayList<>();
      nameToSetMap = Maps.newHashMap();
      modidToSetMap = Maps.newHashMap();

      for (Item item : items) {
         if (isValid(item) && getSet(item) == null) {
            String registryName = getItemRegistryName(item);
            if (!registryNames.contains(registryName) && !registryName.isEmpty()) {
               try {
                  ArmorSet set = new ArmorSet(item);
                  allSets.add(set);
                  nameToSetMap.put(set.registryName, set);
                  TreeSet<ArmorSet> list = modidToSetMap.containsKey(set.modid) ? modidToSetMap.get(set.modid) : Sets.newTreeSet(new Comparator<ArmorSet>() {
                     public int compare(ArmorSet s1, ArmorSet s2) {
                        return s1.registryName.compareTo(s2.registryName);
                     }
                  });
                  list.add(set);
                  modidToSetMap.put(set.modid, list);
                  registryNames.add(registryName);
               } catch (Exception var9) {
                  var9.printStackTrace();
               }
            }
         }
      }
   }

   private static String getNormalDisplayName(Item item) {
      if (item instanceof BlockArmorItem) {
         item = ((BlockArmorItem)item).set.item;
      }

      return new TranslatableComponent(item.getDescriptionId()).getString();
   }

   public static String getItemRegistryName(Item item) {
      try {
         return item.getRegistryName().getPath().toLowerCase().replace(" ", "_");
      } catch (Exception var2) {
         return "";
      }
   }

   public static Component getItemStackDisplayName(Item item, EquipmentSlot slot) {
      String name = getNormalDisplayName(item);
      name = name.replace("Block of ", "")
         .replace("Block ", "")
         .replace(" Block", "")
         .replace("Sugar Canes", "Sugar Cane")
         .replace("Bricks", "Brick")
         .replace("Planks", "Plank");
      name = ChatFormatting.stripFormatting(name);
      if (slot != null) {
         switch (slot) {
            case HEAD:
               return new TranslatableComponent("item.blockarmor.helmet", new Object[]{name});
            case CHEST:
               return new TranslatableComponent("item.blockarmor.chestplate", new Object[]{name});
            case LEGS:
               return new TranslatableComponent("item.blockarmor.leggings", new Object[]{name});
            case FEET:
               return new TranslatableComponent("item.blockarmor.boots", new Object[]{name});
         }
      }

      return new TextComponent(name);
   }

   @Nullable
   public static ItemStack getFirstSetItem(LivingEntity entity, SetEffect effect) {
      ArrayList<ItemStack> stacks = getAllSetItems(entity, effect);
      return stacks.isEmpty() ? null : stacks.get(0);
   }

   @Nullable
   public static ArrayList<ItemStack> getAllSetItems(LivingEntity entity, SetEffect effect) {
      ArrayList<ItemStack> ret = Lists.newArrayList();
      if (effect != null && getWornSetEffects(entity).contains(effect)) {
         for (EquipmentSlot slot : SLOTS) {
            ItemStack stack = entity.getItemBySlot(slot);
            if (stack != null && stack.getItem() instanceof BlockArmorItem && ((BlockArmorItem)stack.getItem()).set.setEffects.contains(effect)) {
               ret.add(stack);
            }
         }
      }

      return ret;
   }

   public static HashSet<SetEffect> getWornSetEffects(LivingEntity entity) {
      return entity != null && getPlayerSetEffects(entity.level.isClientSide).containsKey(entity.getUUID())
         ? getPlayerSetEffects(entity.level.isClientSide).get(entity.getUUID())
         : Sets.newHashSet();
   }

   public static boolean hasSetEffect(LivingEntity entity, SetEffect effect) {
      for (SetEffect effect2 : getWornSetEffects(entity)) {
         if (effect.getClass() == effect2.getClass()) {
            return true;
         }
      }

      return false;
   }

   public static ArmorSet getSet(Block block) {
      for (ArmorSet set : allSets) {
         if (set.block == block) {
            return set;
         }
      }

      return null;
   }

   public static ArmorSet getSet(Item item) {
      for (ArmorSet set : allSets) {
         if (set.item == item) {
            return set;
         }
      }

      return null;
   }

   private static boolean isValid(Item itemIn) {
      try {
         if (itemIn != null && itemIn instanceof BlockItem item) {
            Block block = item.getBlock();
            if ((block instanceof ShulkerBoxBlock || block instanceof BedBlock) && block.getRegistryName().getNamespace().equals("minecraft")) {
               return true;
            } else {
               for (Block manualBlock : MANUALLY_ADDED_SETS) {
                  if (item != null && item == manualBlock.asItem()) {
                     return true;
                  }
               }

               String displayName = getNormalDisplayName(itemIn);
               String registryName = item.getRegistryName().getPath();
               String modid = item.getRegistryName().getNamespace();
               if (modid.contains("one_point_twelve_concrete")
                  || modid.contains("railcraft")
                  || registryName.contains("ore")
                  || registryName.contains("ingot")
                  || displayName.contains(".name")
                  || displayName.contains("Ore")
                  || displayName.contains("%")
                  || displayName.contains("Ingot")) {
                  return false;
               } else if (!(block instanceof LiquidBlock)
                  && !(block instanceof BaseEntityBlock)
                  && !(block instanceof OreBlock)
                  && !(block instanceof CropBlock)
                  && !(block instanceof BushBlock)
                  && block != Blocks.BARRIER
                  && !(block instanceof SlabBlock)
                  && !(block instanceof InfestedBlock)
                  && block.getRenderShape(block.defaultBlockState()) == RenderShape.MODEL
                  && block != Blocks.IRON_BLOCK
                  && block != Blocks.GOLD_BLOCK
                  && block != Blocks.DIAMOND_BLOCK
                  && block != Blocks.AIR
                  && block != Blocks.SNOW
                  && block != Blocks.NETHERITE_BLOCK) {
                  registryName = block.getRegistryName().toString();
                  return registryName.equalsIgnoreCase("evilcraft:darkBlock")
                        || registryName.equalsIgnoreCase("evilcraft:obscuredGlass")
                        || registryName.equalsIgnoreCase("evilcraft:hardenedBlood")
                        || registryName.equalsIgnoreCase("evilcraft:darkPowerGemBlock")
                        || registryName.equalsIgnoreCase("darkutils:filter")
                        || registryName.equalsIgnoreCase("darkutils:filter_inverted")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedanalyser")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedbot")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedmutationstation")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedinscriber")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedhydrophonic")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedresearch")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedpipe")
                        || registryName.equalsIgnoreCase("agriculturalrevolution:rustedironscaff")
                        || registryName.equalsIgnoreCase("tconstruct:clear_glass")
                     ? false
                     : block.defaultBlockState().getCollisionShape(null, BlockPos.ZERO, CollisionContext.empty()) == Shapes.block();
               } else {
                  return false;
               }
            }
         } else {
            return false;
         }
      } catch (Exception var6) {
         return false;
      }
   }

   public boolean isEnabled() {
      return this.enabled;
   }

   public boolean enable() {
      if (!this.enabled && !this.missingTextures) {
         this.enabled = true;
         BlockArmorItem[] armors = new BlockArmorItem[]{this.helmet, this.chestplate, this.leggings, this.boots};

         for (BlockArmorItem armor : armors) {
            if (armor != null) {
               if (this.isFromModdedBlock) {
                  if (BlockArmorCreativeTab.moddedTab == null) {
                     BlockArmorCreativeTab.moddedTab = new BlockArmorCreativeTab("blockArmorModded");
                  }

                  BlockArmorCreativeTab.moddedTab.orderedStacks.add(new ItemStack(armor));
                  armor.group = BlockArmorCreativeTab.moddedTab;
               } else {
                  if (BlockArmorCreativeTab.vanillaTab == null) {
                     BlockArmorCreativeTab.vanillaTab = new BlockArmorCreativeTab("blockArmorVanilla");
                  }

                  BlockArmorCreativeTab.vanillaTab.orderedStacks.add(new ItemStack(armor));
                  armor.group = BlockArmorCreativeTab.vanillaTab;
               }
            }
         }

         return true;
      } else {
         return false;
      }
   }

   public boolean disable() {
      if (!this.enabled) {
         return false;
      } else {
         this.enabled = false;
         BlockArmorItem[] armors = new BlockArmorItem[]{this.helmet, this.chestplate, this.leggings, this.boots};

         for (BlockArmorItem armor : armors) {
            armor.group = null;
            if (BlockArmorCreativeTab.vanillaTab != null && BlockArmorCreativeTab.vanillaTab.orderedStacks != null) {
               for (ItemStack tabStack : BlockArmorCreativeTab.vanillaTab.orderedStacks) {
                  if (tabStack.getItem() == armor) {
                     BlockArmorCreativeTab.vanillaTab.orderedStacks.remove(tabStack);
                     break;
                  }
               }
            }

            if (BlockArmorCreativeTab.moddedTab != null && BlockArmorCreativeTab.moddedTab.orderedStacks != null) {
               for (ItemStack tabStackx : BlockArmorCreativeTab.moddedTab.orderedStacks) {
                  if (tabStackx.getItem() == armor) {
                     BlockArmorCreativeTab.moddedTab.orderedStacks.remove(tabStackx);
                     break;
                  }
               }
            }
         }

         return true;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public Tuple<Integer, Boolean> initTextures() {
      boolean missingTextures = false;
      if (missingSprite == null) {
         missingSprite = MissingTextureAtlasSprite.newInstance(new TextureAtlas(MissingTextureAtlasSprite.getLocation()), 0, 16, 16, 0, 0);
      }

      int numTextures = 0;
      this.textureInfo = Maps.newHashMap();
      BlockState state = this.block.defaultBlockState();
      if (this.block == Blocks.REDSTONE_LAMP) {
         state = (BlockState)state.setValue(RedstoneLampBlock.LIT, true);
      }

      List<BakedQuad> list = new ArrayList<>();

      try {
         BakedModel model = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
         Random rand = new Random();
         list.addAll(model.getQuads(state, null, rand));

         for (Direction facing : Direction.values()) {
            list.addAll(model.getQuads(state, facing, rand));
         }

         for (BakedQuad quad : list) {
            TextureAtlasSprite sprite = quad.getSprite();
            AnimatedTexture animatedTexture = sprite.getFrameCount() > 1 && sprite.getAnimationTicker() instanceof AnimatedTexture
               ? (AnimatedTexture)sprite.getAnimationTicker()
               : null;
            int color = quad.isTinted() ? Minecraft.getInstance().getItemColors().getColor(this.getStack(), quad.getTintIndex()) : -1;
            if (!sprite.getName().toString().contains("overlay")) {
               if (quad.getDirection() == Direction.UP) {
                  if (sprite != missingSprite) {
                     numTextures++;
                  }

                  this.textureInfo.put(EquipmentSlot.HEAD, new TextureInfo(sprite, color, animatedTexture));
               } else if (quad.getDirection() == Direction.NORTH) {
                  if (sprite != missingSprite) {
                     numTextures++;
                  }

                  this.textureInfo.put(EquipmentSlot.CHEST, new TextureInfo(sprite, color, animatedTexture));
               } else if (quad.getDirection() == Direction.SOUTH) {
                  if (sprite != missingSprite) {
                     numTextures++;
                  }

                  this.textureInfo.put(EquipmentSlot.LEGS, new TextureInfo(sprite, color, animatedTexture));
               } else if (quad.getDirection() == Direction.DOWN) {
                  if (sprite != missingSprite) {
                     numTextures++;
                  }

                  this.textureInfo.put(EquipmentSlot.FEET, new TextureInfo(sprite, color, animatedTexture));
               }
            }
         }
      } catch (Exception var13) {
         var13.printStackTrace();
      }

      if (TEXTURE_OVERRIDES.containsKey(this.block)) {
         for (EquipmentSlot slot : TEXTURE_OVERRIDES.get(this.block).overrides.keySet()) {
            ResourceLocation shortLoc = TEXTURE_OVERRIDES.get(this.block).overrides.get(slot).shortLoc;
            ResourceLocation longLoc = TEXTURE_OVERRIDES.get(this.block).overrides.get(slot).longLoc;

            try {
               Minecraft.getInstance().getResourceManager().getResource(longLoc);
               TextureAtlasSprite sprite = Minecraft.getInstance().getModelManager().getAtlas(TextureAtlas.LOCATION_BLOCKS).getSprite(shortLoc);
               this.textureInfo.put(slot, new TextureInfo(sprite, TEXTURE_OVERRIDES.get(this.block).overrides.get(slot).color, null));
            } catch (Exception var12) {
               BlockArmor.LOGGER
                  .error("Override texture for " + this.getStack().getHoverName().getString() + " " + slot.getName() + " NOT found at: " + longLoc);
            }
         }
      }

      for (EquipmentSlot slot : SLOTS) {
         if (!this.textureInfo.containsKey(slot)) {
            this.textureInfo.put(slot, new TextureInfo(null, -1, null));
         }
      }

      if (this.textureInfo.get(EquipmentSlot.HEAD).sprite == missingSprite
         || this.textureInfo.get(EquipmentSlot.CHEST).sprite == missingSprite
         || this.textureInfo.get(EquipmentSlot.LEGS).sprite == missingSprite
         || this.textureInfo.get(EquipmentSlot.FEET).sprite == missingSprite) {
         missingTextures = true;
      }

      return new Tuple(numTextures, missingTextures);
   }

   private static HashMap<UUID, HashSet<SetEffect>> getPlayerSetEffects(boolean isRemote) {
      return isRemote ? playerSetEffectsClient : playerSetEffectsServer;
   }

   @SubscribeEvent
   public static void onEvent(PlayerLoggedOutEvent event) {
      HashMap<UUID, HashSet<SetEffect>> playerSetEffects = getPlayerSetEffects(event.getPlayer().level.isClientSide);
      if (playerSetEffects.containsKey(event.getPlayer().getUUID())) {
         for (SetEffect effect : playerSetEffects.get(event.getPlayer().getUUID())) {
            effect.onStop(event.getPlayer());
         }

         playerSetEffects.remove(event.getPlayer().getUUID());
      }
   }

   @SubscribeEvent
   public static void onEvent(ClientTickEvent event) {
      if (event.phase == Phase.START && Minecraft.getInstance().level != null) {
         updateWornSetEffects(getPlayerSetEffects(true), Minecraft.getInstance().level.players());
      }
   }

   @SubscribeEvent
   public static void onEvent(ServerTickEvent event) {
      if (event.phase == Phase.START) {
         updateWornSetEffects(getPlayerSetEffects(false), ServerLifecycleHooks.getCurrentServer().getPlayerList().getPlayers());
      }
   }

   private static void updateWornSetEffects(HashMap<UUID, HashSet<SetEffect>> playerSetEffects, List<? extends Player> onlinePlayers) {
      for (Player player : onlinePlayers) {
         HashSet<SetEffect> oldEffects = playerSetEffects.get(player.getUUID());
         if (oldEffects == null) {
            oldEffects = Sets.newHashSet();
         }

         HashSet<SetEffect> newEffects = calculateWornSetEffects(player);

         for (SetEffect newEffect : newEffects) {
            if (!oldEffects.contains(newEffect)) {
               newEffect.onStart(player);
            }
         }

         for (SetEffect oldEffect : oldEffects) {
            if (!newEffects.contains(oldEffect)) {
               oldEffect.onStop(player);
            }
         }

         playerSetEffects.put(player.getUUID(), newEffects);
      }
   }

   private static HashSet<SetEffect> calculateWornSetEffects(LivingEntity entity) {
      HashSet<SetEffect> effects = Sets.newHashSet();
      HashMap<SetEffect, Integer> setCounts = Maps.newHashMap();
      if (entity != null) {
         for (EquipmentSlot slot : SLOTS) {
            ItemStack stack = entity.getItemBySlot(slot);
            if (stack != null && stack.getItem() instanceof BlockArmorItem) {
               BlockArmorItem armor = (BlockArmorItem)stack.getItem();

               for (SetEffect effect : armor.set.setEffects) {
                  if (effect.isEnabled()) {
                     int count = 1;
                     if (setCounts.containsKey(effect)) {
                        count += setCounts.get(effect);
                     }

                     setCounts.put(effect, count);
                  }
               }
            }
         }

         for (SetEffect effectx : setCounts.keySet()) {
            if (setCounts.get(effectx) >= Config.piecesForSet) {
               effects.add(effectx);
            }
         }
      }

      return effects;
   }
}
