package twopiradians.blockArmor.common;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.Optional;
import net.minecraft.core.NonNullList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.loot.GlobalLootModifierSerializer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.PacketDistributor;
import twopiradians.blockArmor.common.command.CommandDev;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.common.recipe.RecipeBlockArmor;
import twopiradians.blockArmor.common.seteffect.SetEffectAutoSmelt;
import twopiradians.blockArmor.common.seteffect.SetEffectLucky;
import twopiradians.blockArmor.packet.CActivateSetEffectPacket;
import twopiradians.blockArmor.packet.SDevColorsPacket;
import twopiradians.blockArmor.packet.SSyncCooldownsPacket;

@EventBusSubscriber
public class CommonProxy {
   public static final DeferredRegister<GlobalLootModifierSerializer<?>> LOOT_MODIFIERS = DeferredRegister.create(
      ForgeRegistries.Keys.LOOT_MODIFIER_SERIALIZERS, BlockArmor.MODID
   );
   public static final RegistryObject<SetEffectAutoSmelt.SetEffectAutoSmeltModifier.Serializer> AUTOSMELT = LOOT_MODIFIERS.register(
      "set_effect_autosmelt", SetEffectAutoSmelt.SetEffectAutoSmeltModifier.Serializer::new
   );
   public static final RegistryObject<SetEffectLucky.SetEffectLuckyModifier.Serializer> LUCKY = LOOT_MODIFIERS.register(
      "set_effect_lucky", SetEffectLucky.SetEffectLuckyModifier.Serializer::new
   );

   public static void setup() {
      registerPackets();
   }

   private static void registerPackets() {
      int id = 0;
      BlockArmor.NETWORK
         .registerMessage(
            id++,
            SDevColorsPacket.class,
            SDevColorsPacket::encode,
            SDevColorsPacket::decode,
            SDevColorsPacket.Handler::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT)
         );
      BlockArmor.NETWORK
         .registerMessage(
            id++,
            CActivateSetEffectPacket.class,
            CActivateSetEffectPacket::encode,
            CActivateSetEffectPacket::decode,
            CActivateSetEffectPacket.Handler::handle,
            Optional.of(NetworkDirection.PLAY_TO_SERVER)
         );
      BlockArmor.NETWORK
         .registerMessage(
            id++,
            SSyncCooldownsPacket.class,
            SSyncCooldownsPacket::encode,
            SSyncCooldownsPacket::decode,
            SSyncCooldownsPacket.Handler::handle,
            Optional.of(NetworkDirection.PLAY_TO_CLIENT)
         );
   }

   @SubscribeEvent
   public static void registerCommands(RegisterCommandsEvent event) {
      CommandDev.register(event.getDispatcher());
   }

   @SubscribeEvent
   public static void serverStart(ServerStartedEvent event) {
      registerRecipes(event.getServer());
   }

   private static void registerRecipes(MinecraftServer server) {
      try {
         Field recipesField = ObfuscationReflectionHelper.findField(RecipeManager.class, "f_44007_");
         Map<RecipeType<?>, Map<ResourceLocation, Recipe<?>>> recipes = Maps.newHashMap((Map)recipesField.get(server.getRecipeManager()));

         for (ArmorSet set : ArmorSet.allSets) {
            if (set.isEnabled()) {
               NonNullList<Ingredient> helmetRecipe = NonNullList.of(
                  Ingredient.EMPTY,
                  new Ingredient[]{
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.EMPTY,
                     Ingredient.of(new ItemStack[]{set.getStack()})
                  }
               );
               NonNullList<Ingredient> armorRecipe = NonNullList.of(
                  Ingredient.EMPTY,
                  new Ingredient[]{
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.EMPTY,
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()})
                  }
               );
               NonNullList<Ingredient> legsRecipe = NonNullList.of(
                  Ingredient.EMPTY,
                  new Ingredient[]{
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.EMPTY,
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.EMPTY,
                     Ingredient.of(new ItemStack[]{set.getStack()})
                  }
               );
               NonNullList<Ingredient> bootsRecipe = NonNullList.of(
                  Ingredient.EMPTY,
                  new Ingredient[]{
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.EMPTY,
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.of(new ItemStack[]{set.getStack()}),
                     Ingredient.EMPTY,
                     Ingredient.of(new ItemStack[]{set.getStack()})
                  }
               );
               Map<ResourceLocation, Recipe<?>> map = Maps.newHashMap(recipes.get(RecipeType.CRAFTING));
               map.put(
                  set.helmet.getRegistryName(),
                  new RecipeBlockArmor(
                     set.helmet.getRegistryName(), set, "blockarmor_" + EquipmentSlot.HEAD.getName(), 3, 2, helmetRecipe, new ItemStack(set.helmet)
                  )
               );
               map.put(
                  set.chestplate.getRegistryName(),
                  new RecipeBlockArmor(
                     set.chestplate.getRegistryName(), set, "blockarmor_" + EquipmentSlot.CHEST.getName(), 3, 3, armorRecipe, new ItemStack(set.chestplate)
                  )
               );
               map.put(
                  set.leggings.getRegistryName(),
                  new RecipeBlockArmor(
                     set.leggings.getRegistryName(), set, "blockarmor_" + EquipmentSlot.LEGS.getName(), 3, 3, legsRecipe, new ItemStack(set.leggings)
                  )
               );
               map.put(
                  set.boots.getRegistryName(),
                  new RecipeBlockArmor(
                     set.boots.getRegistryName(), set, "blockarmor_" + EquipmentSlot.FEET.getName(), 3, 2, bootsRecipe, new ItemStack(set.boots)
                  )
               );
               recipes.put(RecipeType.CRAFTING, ImmutableMap.copyOf(map));
               recipesField.set(server.getRecipeManager(), recipes);
            }
         }
      } catch (Exception var10) {
         var10.printStackTrace();
      }
   }

   @SubscribeEvent
   public static void playerJoin(PlayerLoggedInEvent event) {
      if (!event.getPlayer().level.isClientSide && event.getPlayer() instanceof ServerPlayer) {
         BlockArmor.NETWORK.send(PacketDistributor.PLAYER.with(() -> (ServerPlayer)event.getPlayer()), new SDevColorsPacket());
      }
   }

   public static void setWorldTime(Level world, long time) {
      if (world instanceof ServerLevel) {
         ((ServerLevel)world).setDayTime(time);
      }
   }

}
