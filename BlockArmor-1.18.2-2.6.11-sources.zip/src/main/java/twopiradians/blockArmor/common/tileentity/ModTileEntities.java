package twopiradians.blockArmor.common.tileentity;

import net.minecraft.Util;
import net.minecraft.util.datafix.fixes.References;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.BlockEntityType.Builder;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import twopiradians.blockArmor.common.block.ModBlocks;

public class ModTileEntities {
   @EventBusSubscriber(
      modid = "blockarmor",
      bus = Bus.MOD
   )
   public static class RegistrationHandler {
      @SubscribeEvent
      public static void registerTE(Register<BlockEntityType<?>> event) {
         TileEntityMovingLightSource.type = Builder.of(TileEntityMovingLightSource::new, new Block[]{ModBlocks.MOVING_LIGHT_SOURCE})
            .build(Util.fetchChoiceType(References.BLOCK_ENTITY, "light_tile_entity"));
         TileEntityMovingLightSource.type.setRegistryName("blockarmor", "light_tile_entity");
         event.getRegistry().register(TileEntityMovingLightSource.type);
      }
   }
}
