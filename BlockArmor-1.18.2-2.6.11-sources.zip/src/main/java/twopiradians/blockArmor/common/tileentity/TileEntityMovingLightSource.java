package twopiradians.blockArmor.common.tileentity;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import twopiradians.blockArmor.common.block.BlockMovingLightSource;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.common.seteffect.SetEffect;
import twopiradians.blockArmor.common.seteffect.SetEffectIlluminated;

public class TileEntityMovingLightSource extends BlockEntity implements EntityBlock {
   public static BlockEntityType<TileEntityMovingLightSource> type;
   private static final int INITIAL_DESPAWN_TIMER = 5;
   private int despawnTimer;
   private SetEffect effect;

   public TileEntityMovingLightSource(BlockPos pos, BlockState state) {
      this((Integer)state.getValue(BlockMovingLightSource.LIGHT_LEVEL), pos, state);
   }

   public TileEntityMovingLightSource(int lightLevel, BlockPos pos, BlockState state) {
      super(type, pos, state);
      this.effect = new SetEffectIlluminated(lightLevel);
      this.despawnTimer = 5;
   }

   @Nullable
   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
      return TileEntityMovingLightSource::tick;
   }

   public static <T extends BlockEntity> void tick(Level level, BlockPos pos, BlockState state, T te) {
      if (!level.isClientSide && te instanceof TileEntityMovingLightSource light) {
         Player player = level.getNearestPlayer((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5, 2.0, false);
         ItemStack stack = ArmorSet.getFirstSetItem(player, light.effect);
         if ((player == null || stack == null || stack.hasTag() && stack.getTag().getBoolean("deactivated"))
            && level.getBlockState(pos).getBlock() instanceof BlockMovingLightSource) {
            if (--light.despawnTimer <= 0) {
               level.removeBlock(pos, false);
            }
         } else {
            light.despawnTimer = 5;
         }
      }
   }

   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new TileEntityMovingLightSource(pos, state);
   }
}
