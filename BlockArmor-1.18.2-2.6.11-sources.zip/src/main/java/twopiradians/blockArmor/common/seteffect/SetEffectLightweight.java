package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectLightweight extends SetEffect {
   protected SetEffectLightweight() {
      this.color = ChatFormatting.GREEN;
   }

   @SubscribeEvent
   public static void onEvent(LivingFallEvent event) {
      if (ArmorSet.getWornSetEffects(event.getEntityLiving()).contains(SetEffect.LIGHTWEIGHT)) {
         if (event.getEntityLiving().isShiftKeyDown()) {
            event.setDamageMultiplier(0.1F);
         } else {
            event.setDamageMultiplier(0.01F);
            event.setDistance(event.getDistance() / 10.0F);
         }
      }
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (!player.isShiftKeyDown()
         && ArmorSet.getFirstSetItem(player, this) == stack
         && player.getDeltaMovement().y() < 0.0
         && !player.isOnGround()
         && world.isEmptyBlock(player.blockPosition().below(2))
         && world.isClientSide
         && player.fallDistance > 1.0F
         && player.getDeltaMovement().y() < -0.3) {
         player.push(0.0, 0.076, 0.0);
         if (player.fallDistance > 5.0F) {
            double driftX = world.random.nextDouble() - 0.5;
            double driftZ = world.random.nextDouble() - 0.5;
            player.push(driftX / 5.0, 0.0, driftZ / 5.0);
            if (Math.abs(driftX) + Math.abs(driftZ) >= 0.75) {
               world.playSound(player, player.blockPosition(), SoundEvents.GRASS_STEP, SoundSource.PLAYERS, 0.08F, world.random.nextFloat() / 5.0F);
            }
         }
      }
   }

   @Override
   protected boolean isValid(Block block) {
      try {
         return SetEffect.registryNameContains(block, "leaves", "feather") || block instanceof LeavesBlock;
      } catch (Exception var3) {
         return false;
      }
   }
}
