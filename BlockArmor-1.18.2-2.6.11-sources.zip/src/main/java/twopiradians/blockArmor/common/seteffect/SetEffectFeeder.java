package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import twopiradians.blockArmor.common.item.ArmorSet;

public class SetEffectFeeder extends SetEffect {
   protected SetEffectFeeder() {
      this.color = ChatFormatting.RED;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (!player.getCooldowns().isOnCooldown(stack.getItem())
         && !world.isClientSide
         && ArmorSet.getFirstSetItem(player, this) == stack
         && player.canEat(false)) {
         int foodLevel = player.getFoodData().getFoodLevel();
         int foodToFeed = Math.min(20 - foodLevel, 4);
         player.getFoodData().eat(foodToFeed, 0.1F);
         if (foodLevel < 16) {
            for (int i = 0; i < 2; i++) {
               world.playSound(
                  (Player)null, player.blockPosition(), SoundEvents.GENERIC_EAT, SoundSource.PLAYERS, 0.15F, world.random.nextFloat() * 0.2F + 1.0F
               );
            }
         } else {
            world.playSound((Player)null, player.blockPosition(), SoundEvents.PLAYER_BURP, SoundSource.PLAYERS, 0.15F, world.random.nextFloat() * 0.2F + 1.0F);
         }

         this.setCooldown(player, 80);
         this.damageArmor(player, foodToFeed, true);
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "pumpkin", "melon", "food", "berry", "feed", "pork");
   }
}
