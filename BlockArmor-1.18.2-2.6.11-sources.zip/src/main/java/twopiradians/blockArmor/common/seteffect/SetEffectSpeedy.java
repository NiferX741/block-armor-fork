package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;

public class SetEffectSpeedy extends SetEffect {
   protected SetEffectSpeedy() {
      this.color = ChatFormatting.YELLOW;
      this.attributes.put(Attributes.MOVEMENT_SPEED, new AttributeModifier(MOVEMENT_SPEED_UUID, "Movement Speed", 0.1, Operation.ADDITION));
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "fast", "speed", "sugar") || block == Blocks.SUGAR_CANE || block.getSpeedFactor() > 1.0F;
   }
}
