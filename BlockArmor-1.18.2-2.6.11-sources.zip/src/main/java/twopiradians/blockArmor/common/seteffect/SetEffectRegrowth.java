package twopiradians.blockArmor.common.seteffect;

import com.google.common.collect.Lists;
import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.NetherrackBlock;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.common.IPlantable;
import twopiradians.blockArmor.utils.BlockUtils;

public class SetEffectRegrowth extends SetEffect {
   protected SetEffectRegrowth() {
      this.color = ChatFormatting.DARK_GREEN;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (!world.isClientSide && world.random.nextInt(200) == 0 && stack.isDamaged()) {
         stack.setDamageValue(stack.getDamageValue() - 1);
      }
   }

   @Override
   protected boolean isValid(Block block) {
      if (block instanceof NetherrackBlock) {
         return false;
      } else if (!(block instanceof BonemealableBlock)
         && !(block instanceof IPlantable)
         && !SetEffect.registryNameContains(block, "moss", "plant", "mycelium", "mushroom", "flower", "log", "wood", "stem", "plank", "grass", "nether_wart")) {
         Material material = BlockUtils.getMaterial(block);
         return Lists.newArrayList(
               new Material[]{
                  Material.BAMBOO,
                  Material.BAMBOO_SAPLING,
                  Material.CACTUS,
                  Material.VEGETABLE,
                  Material.LEAVES,
                  Material.PLANT,
                  Material.WATER_PLANT,
                  Material.REPLACEABLE_FIREPROOF_PLANT,
                  Material.WATER_PLANT,
                  Material.REPLACEABLE_WATER_PLANT,
                  Material.REPLACEABLE_PLANT,
                  Material.NETHER_WOOD
               }
            )
            .contains(material);
      } else {
         return true;
      }
   }
}
