package twopiradians.blockArmor.common.seteffect;

import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.AbstractCookingRecipe;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.loot.GlobalLootModifierSerializer;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.items.ItemHandlerHelper;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectAutoSmelt extends SetEffect {
   protected SetEffectAutoSmelt() {
      this.color = ChatFormatting.DARK_RED;
      this.usesButton = true;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (ArmorSet.getFirstSetItem(player, this) == stack
         && !world.isClientSide
         && BlockArmor.key.isKeyDown(player)
         && !player.getCooldowns().isOnCooldown(stack.getItem())) {
         boolean deactivated = !stack.getTag().getBoolean("deactivated");
         stack.getTag().putBoolean("deactivated", deactivated);
         player.sendMessage(
            new TranslatableComponent(
               ""
                  + ChatFormatting.GRAY
                  + ChatFormatting.ITALIC
                  + "AutoSmelt set effect "
                  + (deactivated ? "" + ChatFormatting.RED + ChatFormatting.ITALIC + "disabled" : "" + ChatFormatting.GREEN + ChatFormatting.ITALIC + "enabled")
            ),
            UUID.randomUUID()
         );
         this.setCooldown(player, 10);
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "furnace", "fire", "flame", "smelt", "smoker", "coal") && !SetEffect.registryNameContains(block, "coral");
   }

   @SubscribeEvent
   public static void smeltMobDrops(LivingDropsEvent event) {
      if (event.getSource() != null
         && event.getEntity() != null
         && event.getEntity().level instanceof ServerLevel
         && event.getSource().getEntity() instanceof LivingEntity
         && ArmorSet.hasSetEffect((LivingEntity)event.getSource().getEntity(), SetEffect.AUTOSMELT)
         && !(event.getEntity() instanceof Player)) {
         ServerLevel world = (ServerLevel)event.getEntity().level;
         boolean smelted = false;
         ItemStack stack = ArmorSet.getFirstSetItem((LivingEntity)event.getSource().getEntity(), SetEffect.AUTOSMELT);
         if (!stack.hasTag() || stack.getTag().getBoolean("deactivated")) {
            return;
         }

         for (ItemEntity item : event.getDrops()) {
            ItemStack newStack = smelt(item.getItem(), world);
            if (newStack != null) {
               smelted = true;
               item.setItem(newStack);
            }
         }

         if (smelted) {
            Vec3 pos = event.getEntity().position();
            world.sendParticles(ParticleTypes.SMOKE, pos.x() + 0.5, pos.y() + 0.5, pos.z() + 0.5, 10, 0.3F, 0.3F, 0.3F, 0.0);
            world.playSound(null, event.getEntity().blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.3F, world.random.nextFloat() + 0.7F);
            SetEffect.AUTOSMELT.damageArmor((LivingEntity)event.getSource().getEntity(), 1, false);
         }
      }
   }

   @Nullable
   private static ItemStack smelt(ItemStack stack, Level world) {
      return world.getRecipeManager()
         .getRecipeFor(RecipeType.SMELTING, new SimpleContainer(new ItemStack[]{stack}), world)
         .<ItemStack>map(AbstractCookingRecipe::getResultItem)
         .filter(itemStack -> !itemStack.isEmpty())
         .map(itemStack -> ItemHandlerHelper.copyStackWithSize(itemStack, stack.getCount() * itemStack.getCount()))
         .orElse(null);
   }

   public static class SetEffectAutoSmeltModifier extends LootModifier {
      protected SetEffectAutoSmeltModifier(LootItemCondition[] conditionsIn) {
         super(conditionsIn);
      }

      protected List<ItemStack> doApply(List<ItemStack> generatedLoot, LootContext context) {
         Entity entityIn = (Entity)context.getParamOrNull(LootContextParams.THIS_ENTITY);
         if (entityIn instanceof LivingEntity && ArmorSet.hasSetEffect((LivingEntity)entityIn, SetEffect.AUTOSMELT)) {
            LivingEntity entity = (LivingEntity)entityIn;
            ItemStack stack = ArmorSet.getFirstSetItem(entity, SetEffect.AUTOSMELT);
            BlockState state = (BlockState)context.getParamOrNull(LootContextParams.BLOCK_STATE);
            ItemStack tool = (ItemStack)context.getParamOrNull(LootContextParams.TOOL);
            if (entity.level.isClientSide
               || tool != null && EnchantmentHelper.getEnchantments(tool).containsKey(Enchantments.SILK_TOUCH)
               || !stack.hasTag()
               || stack.getTag().getBoolean("deactivated")) {
               return generatedLoot;
            }

            boolean smelted = false;
            ArrayList<ItemStack> newLoot = new ArrayList<>();

            for (ItemStack oldStack : generatedLoot) {
               ItemStack newStack = SetEffectAutoSmelt.smelt(oldStack, context.getLevel());
               if (newStack != null) {
                  smelted = true;
                  newLoot.add(newStack);
               }
            }

            if (!smelted && state != null) {
               ItemStack newStack = SetEffectAutoSmelt.smelt(new ItemStack(state.getBlock()), context.getLevel());
               if (newStack != null) {
                  smelted = true;
               }

               newLoot.add(newStack);
            }

            if (smelted) {
               Vec3 pos = (Vec3)context.getParamOrNull(LootContextParams.ORIGIN);
               context.getLevel().sendParticles(ParticleTypes.SMOKE, pos.x() + 0.5, pos.y() + 0.5, pos.z() + 0.5, 10, 0.3F, 0.3F, 0.3F, 0.0);
               context.getLevel()
                  .playSound(null, entity.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.1F, context.getLevel().random.nextFloat() + 0.7F);
               SetEffect.AUTOSMELT.damageArmor(entity, 1, false);
               return newLoot;
            }
         }

         return generatedLoot;
      }

      public static class Serializer extends GlobalLootModifierSerializer<SetEffectAutoSmelt.SetEffectAutoSmeltModifier> {
         public SetEffectAutoSmelt.SetEffectAutoSmeltModifier read(ResourceLocation location, JsonObject object, LootItemCondition[] conditions) {
            return new SetEffectAutoSmelt.SetEffectAutoSmeltModifier(conditions);
         }

         public JsonObject write(SetEffectAutoSmelt.SetEffectAutoSmeltModifier instance) {
            return this.makeConditions(instance.conditions);
         }
      }
   }
}
