package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectFiery extends SetEffect {
   protected SetEffectFiery() {
      this.color = ChatFormatting.RED;
   }

   @SubscribeEvent
   public static void onEvent(LivingAttackEvent event) {
      if (SetEffect.FIERY.isEnabled() && event.getSource().getEntity() instanceof LivingEntity && !event.getSource().getEntity().level.isClientSide) {
         LivingEntity attacker = (LivingEntity)event.getSource().getEntity();
         LivingEntity attacked = event.getEntityLiving();
         if (ArmorSet.hasSetEffect(attacked, SetEffect.FIERY) && !attacker.isInWater()) {
            if (!attacker.isOnFire() && !attacker.fireImmune()) {
               attacker.level.playSound(null, attacker.getX(), attacker.getY(), attacker.getZ(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.2F, 1.0F);
            }

            attacker.setSecondsOnFire(5);
         }

         if (ArmorSet.hasSetEffect(attacker, SetEffect.FIERY) && !attacked.isInWater()) {
            if (!attacked.isOnFire() && !attacked.fireImmune()) {
               attacker.level.playSound(null, attacked.getX(), attacked.getY(), attacked.getZ(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.4F, 1.0F);
            }

            attacked.setSecondsOnFire(5);
         }
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "netherrack", "magma", "fire", "flame", "lava", "nylium") && !SetEffect.registryNameContains(block, "coral");
   }
}
