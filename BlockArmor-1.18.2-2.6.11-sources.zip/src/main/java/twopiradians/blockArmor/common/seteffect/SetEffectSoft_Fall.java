package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectSoft_Fall extends SetEffect {
   protected SetEffectSoft_Fall() {
      this.color = ChatFormatting.WHITE;
   }

   @SubscribeEvent
   public static void onEvent(LivingFallEvent event) {
      if (ArmorSet.getWornSetEffects(event.getEntityLiving()).contains(SetEffect.SOFT_FALL)) {
         if (!event.getEntityLiving().level.isClientSide && event.getDistance() > 2.0F) {
            event.getEntityLiving()
               .level
               .playSound(
                  null,
                  event.getEntityLiving().blockPosition(),
                  SoundEvents.WOOL_FALL,
                  SoundSource.PLAYERS,
                  Math.min(event.getDistance() / 20.0F, 1.0F),
                  event.getEntityLiving().level.random.nextFloat() + 0.8F
               );
         }

         event.setDistance(0.0F);
         event.setDamageMultiplier(0.0F);
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "wool", "hay", "soft");
   }
}
