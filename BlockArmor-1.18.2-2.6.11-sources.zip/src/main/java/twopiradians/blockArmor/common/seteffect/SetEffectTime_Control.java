package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import twopiradians.blockArmor.client.ClientProxy;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.CommonProxy;
import twopiradians.blockArmor.common.item.ArmorSet;

public class SetEffectTime_Control extends SetEffect {
   private SetEffectTime_Control.Type type;

   protected SetEffectTime_Control(SetEffectTime_Control.Type type) {
      this.type = type;
      this.color = ChatFormatting.LIGHT_PURPLE;
      this.usesButton = true;
   }

   @Override
   public TranslatableComponent getDescription() {
      return new TranslatableComponent(
         "setEffect." + this.name.replaceAll(" ", "_").toLowerCase() + "." + this.type.name.toLowerCase() + ".description", this.getDescriptionObjects()
      );
   }

   @Override
   public String writeToString() {
      return this.name + " (" + this.type.name + ")";
   }

   @Override
   public SetEffect readFromString(String str) throws Exception {
      return new SetEffectTime_Control(SetEffectTime_Control.Type.getType(str.substring(str.indexOf("(") + 1, str.indexOf(")"))));
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (ArmorSet.getFirstSetItem(player, this) == stack && BlockArmor.key.isKeyDown(player)) {
         if (this.type == SetEffectTime_Control.Type.REWIND) {
            if (world.getLevelData().getDayTime() < 21L) {
               this.setWorldTime(world, 23999L + world.getDayTime() - 21L);
            } else {
               this.setWorldTime(world, world.getDayTime() - 21L);
            }

            if (player.tickCount % 4 == 0) {
               world.playSound(player, player.blockPosition(), SoundEvents.LODESTONE_COMPASS_LOCK, SoundSource.PLAYERS, 0.3F, 0.0F);
            }
         } else if (this.type == SetEffectTime_Control.Type.STOP && world.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT)) {
            this.setWorldTime(world, world.getDayTime() - 1L);
            if (player.tickCount % 8 == 0) {
               world.playSound(player, player.blockPosition(), SoundEvents.NOTE_BLOCK_SNARE, SoundSource.PLAYERS, 0.2F, 0.0F);
            }
         } else if (this.type == SetEffectTime_Control.Type.ACCELERATE) {
            this.setWorldTime(world, world.getDayTime() + 19L);
            if (player.tickCount % 2 == 0) {
               world.playSound(player, player.blockPosition(), SoundEvents.LODESTONE_COMPASS_LOCK, SoundSource.PLAYERS, 0.3F, 2.0F);
            }
         }
      }
   }

   public void setWorldTime(Level world, long time) {
      DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientProxy.setWorldTime(world, time));
      DistExecutor.unsafeRunWhenOn(Dist.DEDICATED_SERVER, () -> () -> CommonProxy.setWorldTime(world, time));
   }

   @Override
   protected SetEffect create(Block block) {
      return new SetEffectTime_Control(SetEffectTime_Control.Type.getType(block));
   }

   @Override
   protected boolean isValid(Block block) {
      return block == Blocks.REPEATING_COMMAND_BLOCK || block == Blocks.CHAIN_COMMAND_BLOCK || block == Blocks.COMMAND_BLOCK;
   }

   private static enum Type {
      REWIND(Blocks.REPEATING_COMMAND_BLOCK, "Rewind"),
      STOP(Blocks.CHAIN_COMMAND_BLOCK, "Stop"),
      ACCELERATE(Blocks.COMMAND_BLOCK, "Accelerate");

      public Block block;
      public String name;

      private Type(Block block, String name) {
         this.block = block;
         this.name = name;
      }

      public static SetEffectTime_Control.Type getType(Block block) {
         for (SetEffectTime_Control.Type type : values()) {
            if (type.block == block) {
               return type;
            }
         }

         return ACCELERATE;
      }

      public static SetEffectTime_Control.Type getType(String str) {
         for (SetEffectTime_Control.Type type : values()) {
            if (type.name.equalsIgnoreCase(str)) {
               return type;
            }
         }

         return ACCELERATE;
      }
   }
}
