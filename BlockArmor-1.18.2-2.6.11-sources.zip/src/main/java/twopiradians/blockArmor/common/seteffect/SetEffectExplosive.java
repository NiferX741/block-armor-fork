package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion.BlockInteraction;
import net.minecraft.world.level.block.Block;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.item.ArmorSet;

public class SetEffectExplosive extends SetEffect {
   protected SetEffectExplosive() {
      this.color = ChatFormatting.RED;
      this.usesButton = true;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (!world.isClientSide
         && ArmorSet.getFirstSetItem(player, this) == stack
         && BlockArmor.key.isKeyDown(player)
         && !player.getCooldowns().isOnCooldown(stack.getItem())) {
         tryExplode(this, world, player);
      }
   }

   protected static void tryExplode(SetEffect effect, Level world, Player player) {
      if (!world.isClientSide && player.mayBuild()) {
         effect.setCooldown(player, 20);
         world.explode(player, player.getX(), player.getY() + 0.5, player.getZ(), 6.0F, false, BlockInteraction.BREAK);
         effect.damageArmor(player, 10, true);
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "tnt", "explo");
   }
}
