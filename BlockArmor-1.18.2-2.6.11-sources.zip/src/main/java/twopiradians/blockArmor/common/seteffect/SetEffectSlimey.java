package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.event.TickEvent.PlayerTickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectSlimey extends SetEffect {
   private static LivingEntity bouncingEntity;
   private static double motionY;

   protected SetEffectSlimey() {
      this.color = ChatFormatting.GREEN;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (ArmorSet.getFirstSetItem(player, this) == stack && world.isClientSide && !player.isShiftKeyDown()) {
         if (!player.isOnGround() && !player.isFallFlying()) {
            player.setDeltaMovement(player.getDeltaMovement().x * 1.07, player.getDeltaMovement().y, player.getDeltaMovement().z * 1.07);
         }

         if (!player.getCooldowns().isOnCooldown(stack.getItem())
            && player.horizontalCollision
            && Math.sqrt(Math.pow(player.getX() - player.xCloakO, 2.0) + Math.pow(player.getZ() - player.zCloakO, 2.0)) >= 1.1) {
            this.setCooldown(player, 10);
            double multiplier = 0.1;
            if (player.getDeltaMovement().x == 0.0) {
               player.setDeltaMovement(
                  -(player.getX() - player.xCloakO) * multiplier, player.getDeltaMovement().y + 0.1, (player.getZ() - player.zCloakO) * multiplier
               );
            } else if (player.getDeltaMovement().z == 0.0) {
               player.setDeltaMovement(
                  (player.getX() - player.xCloakO) * multiplier, player.getDeltaMovement().y + 0.1, -(player.getZ() - player.zCloakO) * multiplier
               );
            }

            world.playSound(player, player.getX(), player.getY(), player.getZ(), SoundEvents.SLIME_BLOCK_FALL, SoundSource.BLOCKS, 0.4F, 1.0F);
         }
      }
   }

   @SubscribeEvent
   public static void onEvent(LivingFallEvent event) {
      if (ArmorSet.hasSetEffect(event.getEntityLiving(), SetEffect.SLIMEY)) {
         if (!(event.getEntity() instanceof Player)) {
            return;
         }

         Player player = (Player)event.getEntity();
         if (!player.isShiftKeyDown()) {
            event.setDamageMultiplier(0.0F);
            if (player.level.isClientSide) {
               if (event.getDistance() <= 40.0F && (double)event.getDistance() > 2.0) {
                  player.setDeltaMovement(player.getDeltaMovement().x, Math.abs(player.getDeltaMovement().y * 0.9), player.getDeltaMovement().z);
               } else if (event.getDistance() > 40.0F && event.getDistance() <= 100.0F) {
                  player.setDeltaMovement(player.getDeltaMovement().x, Math.abs(player.getDeltaMovement().y * 0.9 * 1.5), player.getDeltaMovement().z);
               } else if (event.getDistance() > 100.0F) {
                  player.setDeltaMovement(player.getDeltaMovement().x, Math.abs(player.getDeltaMovement().y * 0.9 * 2.0), player.getDeltaMovement().z);
               }

               if ((double)event.getDistance() > 2.0) {
                  player.level
                     .playSound(
                        player,
                        player.getX(),
                        player.getY(),
                        player.getZ(),
                        event.getDistance() > 40.0F ? SoundEvents.SLIME_JUMP : SoundEvents.SLIME_SQUISH,
                        SoundSource.PLAYERS,
                        0.4F,
                        1.0F
                     );
               }

               player.hasImpulse = true;
               player.setOnGround(false);
               player.hurtMarked = true;
               bouncingEntity = player;
               motionY = player.getDeltaMovement().y();
            } else {
               event.setCanceled(true);
            }
         } else {
            event.setDamageMultiplier(0.1F);
         }
      }
   }

   @SubscribeEvent
   public static void onEvent(PlayerTickEvent event) {
      if (bouncingEntity != null && event.player == bouncingEntity && bouncingEntity.level.isClientSide && event.phase == Phase.END) {
         bouncingEntity.setDeltaMovement(bouncingEntity.getDeltaMovement().x, motionY, bouncingEntity.getDeltaMovement().z);
         bouncingEntity.fallDistance = 0.0F;
         bouncingEntity = null;
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "slime");
   }
}
