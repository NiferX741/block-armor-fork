package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.level.block.Block;

public class SetEffectPowerful extends SetEffect {
   protected SetEffectPowerful() {
      this.color = ChatFormatting.WHITE;
      this.attributes.put(Attributes.ATTACK_SPEED, new AttributeModifier(ATTACK_SPEED_UUID, "Attack Speed", 1.0, Operation.ADDITION));
      this.attributes.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(ATTACK_DAMAGE_UUID, "Attack Damage", 3.0, Operation.ADDITION));
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "quartz", "strong", "power");
   }
}
