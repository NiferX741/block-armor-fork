package twopiradians.blockArmor.common.seteffect;

import java.lang.reflect.Method;
import net.minecraft.ChatFormatting;
import net.minecraft.network.protocol.game.ClientboundCustomSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.item.ArmorSet;

public class SetEffectSleepy extends SetEffect {
   private static final Method WAKE_UP_ALL_PLAYERS = ObfuscationReflectionHelper.findMethod(ServerLevel.class, "m_8804_", new Class[0]);
   private static final Method RESET_WEATHER_CYCLE = ObfuscationReflectionHelper.findMethod(ServerLevel.class, "m_184097_", new Class[0]);

   protected SetEffectSleepy() {
      this.color = ChatFormatting.WHITE;
      this.usesButton = true;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (!world.isClientSide
         && BlockArmor.key.isKeyDown(player)
         && ArmorSet.getFirstSetItem(player, this) == stack
         && !player.getCooldowns().isOnCooldown(stack.getItem())) {
         if (!player.level.dimensionType().bedWorks()) {
            SetEffectExplosive.tryExplode(this, world, player);
         } else if (player.level.isNight() && world instanceof ServerLevel) {
            if (world.getGameRules().getBoolean(GameRules.RULE_DAYLIGHT)) {
               long j = world.getDayTime() + 24000L;
               ((ServerLevel)world).setDayTime(ForgeEventFactory.onSleepFinished((ServerLevel)world, j - j % 24000L, world.getDayTime()));
            }

            try {
               WAKE_UP_ALL_PLAYERS.invoke(world);
               if (world.getGameRules().getBoolean(GameRules.RULE_WEATHER_CYCLE) && world.isRaining()) {
                  RESET_WEATHER_CYCLE.invoke(world);
               }
            } catch (Exception var6) {
               var6.printStackTrace();
            }

            if (player instanceof ServerPlayer) {
               ((ServerPlayer)player)
                  .connection
                  .send(new ClientboundCustomSoundPacket(SoundEvents.NOTE_BLOCK_CHIME.getRegistryName(), SoundSource.PLAYERS, player.position(), 0.5F, 1.4F));
            }

            this.setCooldown(player, 100);
         } else if (player instanceof ServerPlayer) {
            ((ServerPlayer)player)
               .connection
               .send(
                  new ClientboundCustomSoundPacket(
                     SoundEvents.NOTE_BLOCK_BASS.getRegistryName(), SoundSource.PLAYERS, player.position(), 1.0F, world.random.nextFloat() + 0.5F
                  )
               );
            this.setCooldown(player, 10);
         }
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "bed", "sleep", "hammock") && !SetEffect.registryNameContains(block, "bedrock");
   }
}
