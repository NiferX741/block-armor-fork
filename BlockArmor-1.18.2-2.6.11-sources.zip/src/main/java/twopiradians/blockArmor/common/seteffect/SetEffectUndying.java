package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectUndying extends SetEffect {
   protected SetEffectUndying() {
      this.color = ChatFormatting.DARK_PURPLE;
   }

   @SubscribeEvent
   public static void onEvent(LivingDeathEvent event) {
      try {
         if (event.getEntityLiving() instanceof ServerPlayer) {
            ServerPlayer player = (ServerPlayer)event.getEntityLiving();
            if (!player.level.isClientSide
               && ArmorSet.hasSetEffect(player, SetEffect.UNDYING)
               && !player.getCooldowns().isOnCooldown(ArmorSet.getFirstSetItem(player, SetEffect.UNDYING).getItem())) {
               player.setHealth(1.0F);
               player.removeAllEffects();
               player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 900, 1));
               player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 100, 1));
               player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 800, 0));
               player.level.broadcastEntityEvent(player, (byte)35);
               SetEffect.UNDYING.setCooldown(player, 6000);
               SetEffect.UNDYING.damageArmor(player, 100, true);
               player.connection
                  .send(
                     new ClientboundSoundPacket(SoundEvents.RESPAWN_ANCHOR_DEPLETE, SoundSource.BLOCKS, player.getX(), player.getY(), player.getZ(), 1.0F, 1.0F)
                  );
               event.setCanceled(true);
            }
         }
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "netherite", "ancient_debris");
   }
}
