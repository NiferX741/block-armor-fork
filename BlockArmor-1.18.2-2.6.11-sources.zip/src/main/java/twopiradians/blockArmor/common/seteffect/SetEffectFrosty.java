package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;

public class SetEffectFrosty extends SetEffect {
   protected SetEffectFrosty() {
      this.color = ChatFormatting.AQUA;
      this.enchantments.add(new SetEffect.EnchantmentData(Enchantments.FROST_WALKER, (short)2, EquipmentSlot.FEET));
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "ice", "snow", "frozen", "frost");
   }
}
