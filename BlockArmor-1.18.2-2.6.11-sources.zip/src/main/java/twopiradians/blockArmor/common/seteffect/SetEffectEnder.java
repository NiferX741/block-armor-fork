package twopiradians.blockArmor.common.seteffect;

import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundCustomSoundPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ClipContext.Block;
import net.minecraft.world.level.ClipContext.Fluid;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.HitResult.Type;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.item.ArmorSet;

public class SetEffectEnder extends SetEffect {
   protected SetEffectEnder() {
      this.color = ChatFormatting.DARK_PURPLE;
      this.usesButton = true;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (!world.isClientSide
         && ArmorSet.getFirstSetItem(player, this) == stack
         && BlockArmor.key.isKeyDown(player)
         && !player.getCooldowns().isOnCooldown(stack.getItem())) {
         float maxYawOffset = 6.0F;
         float yawIncrement = 2.0F;
         float rollIncrement = (float) (Math.PI / 4);
         int radius = 0;
         int distance = 30;
         int maxYOffset = 3;
         HashSet<BlockPos> checkedPositions = Sets.newHashSet();

         for (float yawOffset = 0.0F; yawOffset <= maxYawOffset; yawOffset += yawIncrement) {
            label73:
            for (float roll = 0.0F; (double)roll <= Math.PI * 2; roll += yawOffset == 0.0F ? 999.0F : rollIncrement) {
               HitResult result = this.pick(player, (double)distance, yawOffset, roll);
               if (result.getType() == Type.BLOCK) {
                  LinkedHashSet<BlockPos> positions = Sets.newLinkedHashSet();
                  BlockPos resultPos = new BlockPos(result.getLocation().x(), result.getLocation().y(), result.getLocation().z());
                  positions.add(resultPos);
                  positions.add(resultPos.above());

                  for (int x = -radius; x <= radius; x++) {
                     for (int y = -radius; y <= radius; y++) {
                        for (int z = -radius; z <= radius; z++) {
                           BlockPos pos = new BlockPos(
                              result.getLocation().x() + (double)x, result.getLocation().y() + (double)y, result.getLocation().z() + (double)z
                           );
                           positions.add(pos);
                        }
                     }
                  }

                  Iterator var20 = positions.iterator();

                  BlockPos pos;
                  do {
                     if (!var20.hasNext()) {
                        continue label73;
                     }

                     pos = (BlockPos)var20.next();
                     checkedPositions.add(pos);
                  } while (!this.attemptTeleport(player, (double)pos.getX() + 0.5, (double)pos.getY(), (double)pos.getZ() + 0.5, maxYOffset));

                  if (player.isPassenger()) {
                     player.stopRiding();
                  }

                  world.playSound((Player)null, player.getX(), player.getY(), player.getZ(), SoundEvents.CHORUS_FRUIT_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.0F);
                  world.playSound(
                     (Player)null,
                     (double)pos.getX(),
                     (double)pos.getY(),
                     (double)pos.getZ(),
                     SoundEvents.CHORUS_FRUIT_TELEPORT,
                     SoundSource.PLAYERS,
                     1.0F,
                     1.0F
                  );
                  player.playSound(SoundEvents.CHORUS_FRUIT_TELEPORT, 1.0F, 1.0F);
                  player.fallDistance = 0.0F;
                  this.setCooldown(player, 30);
                  this.damageArmor(player, 2, false);
                  return;
               }
            }
         }

         if (player instanceof ServerPlayer) {
            ((ServerPlayer)player)
               .connection
               .send(
                  new ClientboundCustomSoundPacket(
                     SoundEvents.NOTE_BLOCK_BASS.getRegistryName(), SoundSource.PLAYERS, player.position(), 1.0F, world.random.nextFloat() + 0.5F
                  )
               );
            this.setCooldown(player, 10);
         }
      }
   }

   private boolean attemptTeleport(Player player, double x, double y, double z, int maxYOffset) {
      double d0 = player.getX();
      double d1 = player.getY();
      double d2 = player.getZ();
      double d3 = y;
      boolean flag = false;
      BlockPos blockpos = new BlockPos(x, y, z);
      Level world = player.level;
      if (world.hasChunkAt(blockpos)) {
         boolean flag1 = false;

         while (!flag1 && blockpos.getY() > 0 && maxYOffset-- > 0) {
            BlockPos blockpos1 = blockpos.below();
            BlockState blockstate = world.getBlockState(blockpos1);
            if (blockstate.getMaterial().blocksMotion()) {
               flag1 = true;
            } else {
               d3--;
               blockpos = blockpos1;
            }
         }

         if (flag1) {
            player.teleportTo(x, d3, z);
            if (world.noCollision(player) && !world.containsAnyLiquid(player.getBoundingBox())) {
               flag = true;
            }
         }
      }

      if (!flag) {
         player.teleportTo(d0, d1, d2);
         return false;
      } else {
         world.broadcastEntityEvent(player, (byte)46);
         return true;
      }
   }

   public HitResult pick(Player player, double distance, float yawOffset, float roll) {
      Vec3 start = player.getEyePosition(0.0F);
      Vec3 look = this.getVectorForRotation(player.getXRot() + Mth.sin(roll) * yawOffset, player.yHeadRot + Mth.cos(roll) * yawOffset);
      Vec3 end = start.add(look.x * distance, look.y * distance, look.z * distance);
      return player.level.clip(new ClipContext(start, end, Block.OUTLINE, Fluid.NONE, player));
   }

   public final Vec3 getVectorForRotation(float pitch, float yaw) {
      float f = pitch * (float) (Math.PI / 180.0);
      float f1 = -yaw * (float) (Math.PI / 180.0);
      float f2 = Mth.cos(f1);
      float f3 = Mth.sin(f1);
      float f4 = Mth.cos(f);
      float f5 = Mth.sin(f);
      return new Vec3((double)(f3 * f4), (double)(-f5), (double)(f2 * f4));
   }

   public Vec3 rotateRoll(Vec3 vec, float roll) {
      float f = Mth.cos(roll);
      float f1 = Mth.sin(roll);
      double d0 = vec.x * (double)f + vec.y * (double)f1;
      double d1 = vec.y * (double)f - vec.x * (double)f1;
      double d2 = vec.z;
      return new Vec3(d0, d1, d2);
   }

   @Override
   protected boolean isValid(net.minecraft.world.level.block.Block block) {
      return SetEffect.registryNameContains(block, "end_stone", "end_bricks", "ender", "EndStone", "chorus", "purpur", "teleport");
   }
}
