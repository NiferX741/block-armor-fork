package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.game.ClientboundRespawnPacket;
import net.minecraft.network.protocol.game.ClientboundSetDefaultSpawnPositionPacket;
import net.minecraft.network.protocol.game.ClientboundSetExperiencePacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectRespawn extends SetEffect {
   protected SetEffectRespawn() {
      this.color = ChatFormatting.DARK_PURPLE;
   }

   @SubscribeEvent
   public static void onEvent(LivingDeathEvent event) {
      try {
         if (event.getEntityLiving() instanceof ServerPlayer) {
            ServerPlayer player = (ServerPlayer)event.getEntityLiving();
            if (!player.level.isClientSide
               && ArmorSet.hasSetEffect(player, SetEffect.RESPAWN)
               && !player.getCooldowns().isOnCooldown(ArmorSet.getFirstSetItem(player, SetEffect.RESPAWN).getItem())) {
               player.setHealth(1.0F);
               player.removeAllEffects();
               player.level.broadcastEntityEvent(player, (byte)3);
               player.clearFire();
               player.getCombatTracker().recheckStatus();
               ServerLevel respawnWorld = player.server.getLevel(player.getRespawnDimension());
               if (respawnWorld == null) {
                  respawnWorld = player.server.overworld();
               }

               BlockPos respawnPos = player.getRespawnPosition();
               if (respawnPos == null) {
                  respawnPos = respawnWorld.getSharedSpawnPos();
               }

               if (respawnWorld != player.level) {
                  player.handleInsidePortal(player.blockPosition());
                  player.changeDimension(respawnWorld);
               }

               player.moveTo((double)respawnPos.getX(), (double)respawnPos.getY(), (double)respawnPos.getZ(), 0.0F, 0.0F);
               player.setRespawnPosition(respawnWorld.dimension(), respawnPos, player.getRespawnAngle(), player.isRespawnForced(), false);
               player.connection
                  .send(
                     new ClientboundRespawnPacket(
                        player.level.dimensionTypeRegistration(),
                        player.level.dimension(),
                        BiomeManager.obfuscateSeed(player.getLevel().getSeed()),
                        player.gameMode.getGameModeForPlayer(),
                        player.gameMode.getPreviousGameModeForPlayer(),
                        player.getLevel().isDebug(),
                        player.getLevel().isFlat(),
                        true
                     )
                  );
               player.connection.teleport(player.getX(), player.getY(), player.getZ(), player.getYRot(), player.getXRot());
               player.connection.send(new ClientboundSetDefaultSpawnPositionPacket(respawnWorld.getSharedSpawnPos(), respawnWorld.getSharedSpawnAngle()));
               player.connection.send(new ClientboundSetExperiencePacket(player.experienceProgress, player.totalExperience, player.experienceLevel));
               player.initMenu(player.containerMenu);
               SetEffect.RESPAWN.setCooldown(player, 6000);
               SetEffect.RESPAWN.damageArmor(player, 100, true);
               player.connection
                  .send(
                     new ClientboundSoundPacket(SoundEvents.RESPAWN_ANCHOR_DEPLETE, SoundSource.BLOCKS, player.getX(), player.getY(), player.getZ(), 1.0F, 1.0F)
                  );
               event.setCanceled(true);
            }
         }
      } catch (Exception var4) {
         var4.printStackTrace();
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "respawn");
   }
}
