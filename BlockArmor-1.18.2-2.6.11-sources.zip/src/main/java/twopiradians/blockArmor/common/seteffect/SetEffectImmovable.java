package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.level.block.Block;
import twopiradians.blockArmor.utils.BlockUtils;

public class SetEffectImmovable extends SetEffect {
   private double knockbackResistance;

   protected SetEffectImmovable(double knockbackResistance) {
      this.knockbackResistance = knockbackResistance;
      this.color = ChatFormatting.GRAY;
      this.attributes
         .put(
            Attributes.KNOCKBACK_RESISTANCE, new AttributeModifier(KNOCKBACK_RESISTANCE_UUID, "Knockback Resistance", knockbackResistance, Operation.ADDITION)
         );
   }

   @Override
   public Object[] getDescriptionObjects() {
      return new Object[]{(int)(this.knockbackResistance * 100.0)};
   }

   @Override
   protected SetEffect create(Block block) {
      double hardness = (double)BlockUtils.getHardness(block);
      if (hardness == -1.0) {
         hardness = 100.0;
      } else {
         hardness = Math.max(25.0, Math.min(100.0, hardness * 1.5));
      }

      return new SetEffectImmovable(hardness / 100.0);
   }

   @Override
   public String writeToString() {
      return this.name + " (" + this.knockbackResistance + ")";
   }

   @Override
   public SetEffect readFromString(String str) throws Exception {
      return new SetEffectImmovable(Double.valueOf(str.substring(str.indexOf("(") + 1, str.indexOf(")"))));
   }

   @Override
   protected boolean isValid(Block block) {
      if (SetEffect.registryNameContains(block, "bedrock", "obsidian", "brick", "heavy", "sturdy")) {
         float hardness = BlockUtils.getHardness(block);
         if (hardness == -1.0F || hardness >= 2.0F) {
            return true;
         }
      }

      return false;
   }
}
