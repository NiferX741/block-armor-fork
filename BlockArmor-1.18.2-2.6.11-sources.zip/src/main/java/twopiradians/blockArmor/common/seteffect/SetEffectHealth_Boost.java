package twopiradians.blockArmor.common.seteffect;

import com.google.common.collect.Sets;
import java.util.HashSet;
import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.event.entity.player.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.utils.BlockUtils;

@EventBusSubscriber
public class SetEffectHealth_Boost extends SetEffect {
   private static HashSet<ServerPlayer> playersToCheck = Sets.newHashSet();
   private double healthBoost;

   protected SetEffectHealth_Boost(double healthBoost) {
      this.healthBoost = healthBoost;
      this.color = ChatFormatting.RED;
      this.attributes.put(Attributes.MAX_HEALTH, new AttributeModifier(MAX_HEALTH_UUID, "Max Health", healthBoost, Operation.ADDITION));
   }

   @Override
   public Object[] getDescriptionObjects() {
      return new Object[]{(int)this.healthBoost / 2};
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      if (!world.isClientSide && playersToCheck.contains(player)) {
         if (player.getHealth() >= 20.0F) {
            float amount = 0.0F;

            for (SetEffect effect : ArmorSet.getWornSetEffects(player)) {
               if (effect instanceof SetEffectHealth_Boost) {
                  amount = (float)((double)amount + ((SetEffectHealth_Boost)effect).healthBoost);
               }
            }

            player.setHealth(player.getHealth() + amount);
         }

         playersToCheck.remove(player);
      }
   }

   @SubscribeEvent
   public static void onLogin(PlayerLoggedInEvent event) {
      if (!event.getPlayer().level.isClientSide && event.getPlayer() instanceof ServerPlayer) {
         playersToCheck.add((ServerPlayer)event.getPlayer());
      }
   }

   @SubscribeEvent
   public static void onRespawn(PlayerRespawnEvent event) {
      if (!event.getPlayer().level.isClientSide && event.getPlayer() instanceof ServerPlayer) {
         playersToCheck.add((ServerPlayer)event.getPlayer());
      }
   }

   @Override
   protected SetEffect create(Block block) {
      double healthBoost = (double)BlockUtils.getHardness(block);
      if (healthBoost == -1.0 || healthBoost >= 100.0) {
         healthBoost = 100.0;
      }

      healthBoost = Math.max(healthBoost * 0.4, 4.0);
      return new SetEffectHealth_Boost(healthBoost);
   }

   @Override
   public String writeToString() {
      return this.name + " (" + this.healthBoost + ")";
   }

   @Override
   public SetEffect readFromString(String str) throws Exception {
      return new SetEffectHealth_Boost(Double.valueOf(str.substring(str.indexOf("(") + 1, str.indexOf(")"))));
   }

   @Override
   protected boolean isValid(Block block) {
      if (SetEffect.registryNameContains(block, "bedrock", "obsidian", "brick", "heal", "heart")) {
         float hardness = BlockUtils.getHardness(block);
         if (hardness == -1.0F || hardness >= 2.0F) {
            return true;
         }
      }

      return false;
   }
}
