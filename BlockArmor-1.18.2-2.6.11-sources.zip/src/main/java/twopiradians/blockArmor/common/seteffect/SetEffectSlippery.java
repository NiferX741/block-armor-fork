package twopiradians.blockArmor.common.seteffect;

import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;
import twopiradians.blockArmor.common.item.ArmorSet;

public class SetEffectSlippery extends SetEffect {
   protected SetEffectSlippery() {
      this.color = ChatFormatting.AQUA;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      if (world.isClientSide && ArmorSet.getFirstSetItem(player, this) == stack && player.isOnGround() && player.zza == 0.0F && player.xxa == 0.0F) {
         Block block = world.getBlockState(player.blockPosition().below()).getBlock();
         if (!(block instanceof AirBlock) && block.getFriction() <= 0.6F) {
            if (Math.abs(player.getDeltaMovement().x()) < 0.4) {
               player.setDeltaMovement(
                  new Vec3(player.getDeltaMovement().x() * (player.isInWater() ? 1.2 : 1.6), player.getDeltaMovement().y(), player.getDeltaMovement().z())
               );
            }

            if (Math.abs(player.getDeltaMovement().z()) < 0.4) {
               player.setDeltaMovement(
                  new Vec3(player.getDeltaMovement().x(), player.getDeltaMovement().y(), player.getDeltaMovement().z() * (player.isInWater() ? 1.2 : 1.6))
               );
            }
         }
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "waxed") || block.getFriction() > 0.6F && !SetEffect.registryNameContains(block, "slime");
   }
}
