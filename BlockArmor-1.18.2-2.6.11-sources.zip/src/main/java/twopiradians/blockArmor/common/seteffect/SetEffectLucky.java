package twopiradians.blockArmor.common.seteffect;

import com.google.gson.JsonObject;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.OreBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.loot.GlobalLootModifierSerializer;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.event.entity.living.LootingLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import twopiradians.blockArmor.common.item.ArmorSet;

@EventBusSubscriber
public class SetEffectLucky extends SetEffect {
   protected SetEffectLucky() {
      this.color = ChatFormatting.DARK_GREEN;
      this.attributes.put(Attributes.LUCK, new AttributeModifier(LUCK_UUID, "Luck", 3.0, Operation.ADDITION));
   }

   @SubscribeEvent
   public static void addLooting(LootingLevelEvent event) {
      if (event.getDamageSource() != null
         && event.getDamageSource().getEntity() instanceof Player
         && event.getEntity().level instanceof ServerLevel
         && ArmorSet.getWornSetEffects((LivingEntity)event.getDamageSource().getEntity()).contains(SetEffect.LUCKY)) {
         event.setLootingLevel(event.getLootingLevel() + 4);
         SetEffect.LUCKY
            .doParticlesAndSound((ServerLevel)event.getEntity().level, event.getEntity().blockPosition(), (Player)event.getDamageSource().getEntity(), 4.0F);
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "emerald", "luck");
   }

   private void doParticlesAndSound(Level world, BlockPos pos, LivingEntity player, float amplifier) {
      if (world instanceof ServerLevel) {
         ((ServerLevel)world)
            .sendParticles(ParticleTypes.HAPPY_VILLAGER, (double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5, 5, 0.4F, 0.4F, 0.4F, 0.0);
         world.playSound(
            null,
            player.getX(),
            player.getY(),
            player.getZ(),
            SoundEvents.PLAYER_LEVELUP,
            SoundSource.PLAYERS,
            0.05F * amplifier,
            world.random.nextFloat() + 0.9F
         );
      }
   }

   public static class SetEffectLuckyModifier extends LootModifier {
      protected SetEffectLuckyModifier(LootItemCondition[] conditionsIn) {
         super(conditionsIn);
      }

      protected List<ItemStack> doApply(List<ItemStack> generatedLoot, LootContext context) {
         Entity entityIn = (Entity)context.getParamOrNull(LootContextParams.THIS_ENTITY);
         if (entityIn instanceof LivingEntity && ArmorSet.getWornSetEffects((LivingEntity)entityIn).contains(SetEffect.LUCKY)) {
            LivingEntity entity = (LivingEntity)entityIn;
            Vec3 pos = (Vec3)context.getParamOrNull(LootContextParams.ORIGIN);
            BlockState state = (BlockState)context.getParamOrNull(LootContextParams.BLOCK_STATE);
            ItemStack tool = (ItemStack)context.getParamOrNull(LootContextParams.TOOL);
            Item item = state != null ? state.getBlock().asItem() : null;
            if (item != null) {
               for (ItemStack stack : generatedLoot) {
                  if (stack != null && stack.getItem() == item) {
                     return generatedLoot;
                  }
               }
            }

            if (pos != null
               && state != null
               && state.getBlock() instanceof OreBlock
               && (tool == null || EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, tool) <= 0)) {
               int beforeCount = 0;
               int afterCount = 0;

               for (ItemStack stackx : generatedLoot) {
                  beforeCount += stackx.getCount();
                  stackx.setCount(Math.min(stackx.getCount() * 2, stackx.getMaxStackSize()));
                  afterCount += stackx.getCount();
               }

               if (afterCount > beforeCount) {
                  SetEffect.LUCKY.doParticlesAndSound(entity.level, new BlockPos(pos), entity, (float)(afterCount - beforeCount));
                  SetEffect.LUCKY.damageArmor(entity, afterCount - beforeCount, false);
               }
            }
         }

         return generatedLoot;
      }

      public static class Serializer extends GlobalLootModifierSerializer<SetEffectLucky.SetEffectLuckyModifier> {
         public SetEffectLucky.SetEffectLuckyModifier read(ResourceLocation location, JsonObject object, LootItemCondition[] conditions) {
            return new SetEffectLucky.SetEffectLuckyModifier(conditions);
         }

         public JsonObject write(SetEffectLucky.SetEffectLuckyModifier instance) {
            return this.makeConditions(instance.conditions);
         }
      }
   }
}
