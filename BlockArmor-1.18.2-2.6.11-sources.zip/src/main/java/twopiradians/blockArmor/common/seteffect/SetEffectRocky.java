package twopiradians.blockArmor.common.seteffect;

import java.lang.reflect.Field;
import net.minecraft.ChatFormatting;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;

public class SetEffectRocky extends SetEffect {
   private static final Field WAS_TOUCHING_WATER_FIELD = ObfuscationReflectionHelper.findField(Entity.class, "f_19798_");
   private static final Field FIRST_TICK_FIELD = ObfuscationReflectionHelper.findField(Entity.class, "f_19803_");

   protected SetEffectRocky() {
      this.color = ChatFormatting.GRAY;
   }

   @Override
   public void onArmorTick(Level world, Player player, ItemStack stack) {
      super.onArmorTick(world, player, stack);
      Vec3 motion = player.getDeltaMovement();
      if (player.isInWater()) {
         player.setSwimming(false);

         try {
            WAS_TOUCHING_WATER_FIELD.set(player, false);
            FIRST_TICK_FIELD.set(player, true);
         } catch (Exception var6) {
            var6.printStackTrace();
         }

         if ((Math.abs(motion.x) > 0.0 || Math.abs(motion.z) > 0.0 || motion.y > 0.0) && EnchantmentHelper.getDepthStrider(player) == 0) {
            player.setSprinting(false);
            player.setDeltaMovement(motion.x() * (player.isOnGround() ? 0.14 : 1.0), motion.y(), motion.z() * (player.isOnGround() ? 0.14 : 1.0));
            if (player.isOnGround()) {
               player.hurtMarked = true;
            }

            player.hasImpulse = true;
         }
      }
   }

   @Override
   protected boolean isValid(Block block) {
      return SetEffect.registryNameContains(block, "rock", "stone", "deepslate", "tuff");
   }
}
