package twopiradians.blockArmor.common.config;

import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.common.ForgeConfigSpec.BooleanValue;
import net.minecraftforge.common.ForgeConfigSpec.Builder;
import net.minecraftforge.common.ForgeConfigSpec.ConfigValue;
import net.minecraftforge.common.ForgeConfigSpec.DoubleValue;
import net.minecraftforge.common.ForgeConfigSpec.IntValue;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import org.apache.commons.lang3.tuple.Pair;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.common.seteffect.SetEffect;

@EventBusSubscriber(
   modid = "blockarmor",
   bus = Bus.MOD
)
public class Config {
   private static final double CONFIG_VERSION = 1.1;
   public static int piecesForSet;
   public static ArrayList<ArmorSet> disabledSets;
   public static boolean effectsUseDurability;
   public static double globalToughnessModifier;
   public static double globalEnchantabilityModifier;
   public static double globalDamageReductionModifier;
   public static double globalKnockbackResistanceModifier;
   public static double globalDurabilityModifier;
   public static ForgeConfigSpec SERVER_SPEC;
   public static Config.Server SERVER;

   public static ForgeConfigSpec init() {
      Pair<Config.Server, ForgeConfigSpec> specPair = new Builder().configure(Config.Server::new);
      SERVER_SPEC = (ForgeConfigSpec)specPair.getRight();
      SERVER = (Config.Server)specPair.getLeft();
      return SERVER_SPEC;
   }

   public static void sync() {
      boolean oldVersion = (Double)Config.Server.configVersion.get() != 1.1;
      piecesForSet = (Integer)Config.Server.piecesForSet.get();
      effectsUseDurability = Config.Server.effectsUseDurability.get() == null || (Boolean)Config.Server.effectsUseDurability.get();
      globalDamageReductionModifier = (Double)Config.Server.globalDamageReductionModifier.get();
      globalDurabilityModifier = (Double)Config.Server.globalDurabilityModifier.get();
      globalEnchantabilityModifier = (Double)Config.Server.globalEnchantabilityModifier.get();
      globalKnockbackResistanceModifier = (Double)Config.Server.globalKnockbackResistanceModifier.get();
      globalToughnessModifier = (Double)Config.Server.globalToughnessModifier.get();

      for (ArmorSet set : ArmorSet.allSets) {
         Config.ArmorSetOptions options = Config.Server.armorSetOptions.get(set);
         if (set.helmet != null) {
            Boolean enabled = (Boolean)options.enabled.get();
            if (enabled != null && !enabled) {
               set.disable();
            } else {
               set.enable();
            }
         }

         set.armorDurability = (Integer)options.armorDurability.get();
         set.armorDamageReduction = ((Double)options.armorDamageReduction.get()).floatValue();
         set.armorToughness = ((Double)options.armorToughness.get()).floatValue();
         set.armorEnchantability = (Integer)options.armorEnchantability.get();
         set.armorKnockbackResistance = (Integer)options.armorKnockbackResistance.get();
         set.createMaterial();
         if (oldVersion) {
            options.setEffects.set(set.defaultSetEffects.stream().map(SetEffect::writeToString).collect(Collectors.toList()));
         }

         set.setEffects.clear();

         for (String str : options.setEffects.get()) {
            SetEffect effect = SetEffect.getEffectFromString(str);
            if (effect != null) {
               set.setEffects.add(effect);
            } else {
               BlockArmor.LOGGER.warn("Invalid set effect in config for " + set.registryName + ": " + str);
            }
         }
      }

      if (oldVersion) {
         Config.Server.configVersion.set(1.1);
      }
   }

   @SubscribeEvent
   public static void onLoad(ModConfigEvent configEvent) {
      BlockArmor.LOGGER.info("Syncing config!");
      sync();
   }

   private static class ArmorSetOptions {
      private BooleanValue enabled;
      private ConfigValue<List<? extends String>> setEffects;
      private ConfigValue<Double> armorDamageReduction;
      private ConfigValue<Integer> armorDurability;
      private ConfigValue<Double> armorToughness;
      private ConfigValue<Integer> armorKnockbackResistance;
      private ConfigValue<Integer> armorEnchantability;
   }

   public static class Server {
      private static HashMap<ArmorSet, Config.ArmorSetOptions> armorSetOptions = Maps.newHashMap();
      private static IntValue piecesForSet;
      private static BooleanValue effectsUseDurability;
      private static DoubleValue globalToughnessModifier;
      private static DoubleValue globalEnchantabilityModifier;
      private static DoubleValue globalDamageReductionModifier;
      private static DoubleValue globalKnockbackResistanceModifier;
      private static DoubleValue globalDurabilityModifier;
      private static ConfigValue<Double> configVersion;

      private Server(Builder builder) {
         configVersion = builder.define("Config version - DO NOT CHANGE", 1.1);
         builder.comment("General settings");
         builder.push("General");
         builder.comment("Specifies how many armor pieces must be worn for a set's effects to work.");
         piecesForSet = builder.defineInRange("Armor pieces required for Set Effects", 2, 1, 4);
         builder.comment("Should Set Effects use durability of worn armor to work");
         effectsUseDurability = builder.define("Set Effects use durability", false);
         builder.pop();
         builder.comment("Settings that affect armor stats for all sets");
         builder.push("Armor Stats");
         builder.comment("Multiplied by armor's durability");
         globalDurabilityModifier = builder.defineInRange("Global Durability Modifier", 1.0, 0.0, 999999.0);
         builder.comment("Multiplied by armor's damage reduction");
         globalDamageReductionModifier = builder.defineInRange("Global Damage Reduction Modifier", 1.0, 0.0, 999999.0);
         builder.comment("Multiplied by armor's toughness");
         globalToughnessModifier = builder.defineInRange("Global Tougness Modifier", 1.0, 0.0, 999999.0);
         builder.comment("Multiplied by armor's knockback resistance");
         globalKnockbackResistanceModifier = builder.defineInRange("Global Knockback Resistance Modifier", 1.0, 0.0, 999999.0);
         builder.comment("Multiplied by armor's enchantability");
         globalEnchantabilityModifier = builder.defineInRange("Global Enchantability Modifier", 1.0, 0.0, 999999.0);
         builder.pop();
         builder.comment("Configure armor sets and their set effects");
         builder.push("Armor_Sets");

         for (String modid : ArmorSet.modidToSetMap.keySet()) {
            builder.push(modid);

            for (ArmorSet set : ArmorSet.modidToSetMap.get(modid)) {
               Config.ArmorSetOptions options = new Config.ArmorSetOptions();
               builder.push(set.registryName);
               options.enabled = builder.define("Enabled", true);
               options.armorDurability = builder.define("Armor_Durability", set.armorDurability);
               options.armorDamageReduction = builder.define("Armor_Damage_Reduction", (double)set.armorDamageReduction);
               options.armorToughness = builder.define("Armor_Toughness", (double)set.armorToughness);
               options.armorKnockbackResistance = builder.define("Armor_Knockback_Resistance", set.armorKnockbackResistance);
               options.armorEnchantability = builder.define("Armor_Enchantability", set.armorEnchantability);
               options.setEffects = builder.defineList(
                  "Set_Effects",
                  set.defaultSetEffects.stream().map(SetEffect::writeToString).collect(Collectors.toList()),
                  effect -> SetEffect.getEffectFromString((String)effect) != null
               );
               builder.pop();
               armorSetOptions.put(set, options);
            }

            builder.pop();
         }

         builder.pop();
      }
   }
}
