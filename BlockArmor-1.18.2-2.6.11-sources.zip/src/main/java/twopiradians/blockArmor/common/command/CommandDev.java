package twopiradians.blockArmor.common.command;

import com.google.common.collect.Maps;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.stream.Collectors;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.commands.synchronization.SuggestionProviders;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.PacketDistributor;
import twopiradians.blockArmor.common.BlockArmor;
import twopiradians.blockArmor.common.item.ArmorSet;
import twopiradians.blockArmor.common.item.BlockArmorItem;
import twopiradians.blockArmor.packet.SDevColorsPacket;

public class CommandDev {
   private static HashMap<String, ArmorSet> setMap = Maps.newHashMap();
   public static final ArrayList<UUID> DEVS = new ArrayList<UUID>() {
      {
         this.add(UUID.fromString("f08951bc-e379-4f19-a113-7728b0367647"));
         this.add(UUID.fromString("93d28330-e1e2-447b-b552-00cb13e9afbd"));
      }
   };
   public static HashMap<UUID, Float[]> devColors = Maps.newHashMap();
   private static final SuggestionProvider<CommandSourceStack> SETS_SUGGESTION = SuggestionProviders.register(
      new ResourceLocation("blockarmor", "armor_sets"),
      (context, builder) -> SharedSuggestionProvider.suggestResource(
            setMap.keySet().stream().map(str -> new ResourceLocation(str)).collect(Collectors.toList()), builder
         )
   );

   public static void addBlockName(ArmorSet set) {
      if (!setMap.containsKey(set)) {
         String name = "";

         try {
            name = ArmorSet.getItemRegistryName(set.item);
            name = name.replace(" ", "_");
            name = ChatFormatting.stripFormatting(name);
            name = name.toLowerCase();
         } catch (Exception var3) {
         }

         if (!name.equals("")) {
            setMap.put(name, set);
         }
      }
   }

   public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
      dispatcher.register(
         (LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.literal("dev")
                  .requires(source -> source.getEntity() instanceof Player ? DEVS.contains(((Player)source.getEntity()).getUUID()) : false))
               .then(
                  Commands.literal("armor")
                     .then(
                        Commands.argument("set", ResourceLocationArgument.id())
                           .suggests(SETS_SUGGESTION)
                           .executes(context -> setArmorSet((CommandSourceStack)context.getSource(), context))
                     )
               ))
            .then(
               Commands.literal("color")
                  .then(
                     Commands.argument("red", FloatArgumentType.floatArg(-1.0F, 1.0F))
                        .then(
                           Commands.argument("green", FloatArgumentType.floatArg(-1.0F, 1.0F))
                              .then(
                                 Commands.argument("blue", FloatArgumentType.floatArg(-1.0F, 1.0F))
                                    .executes(context -> setArmorColor((CommandSourceStack)context.getSource(), context))
                              )
                        )
                  )
            )
      );
   }

   public static int setArmorColor(CommandSourceStack source, CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
      ServerPlayer player = source.getPlayerOrException();
      float red = FloatArgumentType.getFloat(context, "red");
      float green = FloatArgumentType.getFloat(context, "green");
      float blue = FloatArgumentType.getFloat(context, "blue");
      if (red == -1.0F && green == -1.0F && blue == -1.0F) {
         devColors.remove(player.getUUID());
      } else if (red == 0.0F && green == 0.0F && blue == 0.0F) {
         devColors.put(player.getUUID(), new Float[]{0.0F, 0.0F, 0.0F});
      } else {
         devColors.put(player.getUUID(), new Float[]{1.0F - red, 1.0F - green, 1.0F - blue});
      }

      BlockArmor.NETWORK.send(PacketDistributor.ALL.noArg(), new SDevColorsPacket());
      return 1;
   }

   public static int setArmorSet(CommandSourceStack source, CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
      ServerPlayer player = source.getPlayerOrException();
      ResourceLocation loc = ResourceLocationArgument.getId(context, "set");
      ArmorSet set = setMap.get(loc.getPath().toLowerCase());
      if (set == null) {
         player.sendMessage(new TranslatableComponent(ChatFormatting.RED + "Invalid block"), UUID.randomUUID());
         return 0;
      } else {
         for (EquipmentSlot slot : ArmorSet.SLOTS) {
            ItemStack stack = player.getItemBySlot(slot);
            ItemStack newStack = new ItemStack(set.getArmorForSlot(slot));
            CompoundTag nbt = new CompoundTag();
            nbt.putBoolean("devSpawned", true);
            newStack.setTag(nbt);
            if (stack == null || stack.isEmpty() || stack.getItem() instanceof BlockArmorItem) {
               player.setItemSlot(slot, newStack);
            }
         }

         player.sendMessage(new TranslatableComponent(ChatFormatting.GREEN + "Spawned set for " + loc.getPath()), UUID.randomUUID());
         return 1;
      }
   }
}
