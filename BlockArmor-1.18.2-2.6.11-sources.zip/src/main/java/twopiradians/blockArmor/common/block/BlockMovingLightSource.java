package twopiradians.blockArmor.common.block;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import twopiradians.blockArmor.client.ClientProxy;
import twopiradians.blockArmor.common.tileentity.TileEntityMovingLightSource;

public class BlockMovingLightSource extends BaseEntityBlock {
   public static final Property<Integer> LIGHT_LEVEL = IntegerProperty.create("light_level", 1, 15);

   public BlockMovingLightSource() {
      super(Properties.of(Material.AIR).lightLevel(state -> (Integer)state.getValue(LIGHT_LEVEL)));
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{LIGHT_LEVEL});
   }

   public VoxelShape getShape(BlockState p_220053_1_, BlockGetter p_220053_2_, BlockPos p_220053_3_, CollisionContext p_220053_4_) {
      return Shapes.empty();
   }

   public RenderShape getRenderShape(BlockState state) {
      return RenderShape.INVISIBLE;
   }

   public boolean canBeReplaced(BlockState state, BlockPlaceContext useContext) {
      return true;
   }

   public void setPlacedBy(Level world, BlockPos pos, BlockState state, LivingEntity entity, ItemStack stack) {
      world.getBlockEntity(pos);
   }

   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new TileEntityMovingLightSource((Integer)state.getValue(LIGHT_LEVEL), pos, state);
   }

   public StateDefinition<Block, BlockState> getStateDefinition() {
      DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientProxy.mapUnbakedModels());
      return super.getStateDefinition();
   }

   public boolean isAir(BlockState state) {
      return false;
   }

   @Nullable
   public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
      return level.isClientSide ? null : createTickerHelper(type, TileEntityMovingLightSource.type, TileEntityMovingLightSource::tick);
   }
}
