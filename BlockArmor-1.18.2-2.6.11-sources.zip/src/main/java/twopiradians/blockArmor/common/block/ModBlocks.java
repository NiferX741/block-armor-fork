package twopiradians.blockArmor.common.block;

import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraftforge.registries.IForgeRegistry;

public class ModBlocks {
   public static final BlockMovingLightSource MOVING_LIGHT_SOURCE = new BlockMovingLightSource();
   public static ArrayList<Block> allBlocks = new ArrayList<>();

   public static void registerRenders() {
      for (Block block : allBlocks) {
         Minecraft.getInstance()
            .getItemRenderer()
            .getItemModelShaper()
            .register(Item.byBlock(block), new ModelResourceLocation(block.getRegistryName(), "inventory"));
      }
   }

   @EventBusSubscriber(
      bus = Bus.MOD
   )
   public static class RegistrationHandler {
      @SubscribeEvent
      public static void registerBlocks(Register<Block> event) {
         register(event.getRegistry(), ModBlocks.MOVING_LIGHT_SOURCE, "moving_light_source");
      }

      private static void register(IForgeRegistry<Block> registry, Block block, String blockName) {
         ModBlocks.allBlocks.add(block);
         block.setRegistryName("blockarmor", blockName);
         registry.register(block);
      }
   }
}
