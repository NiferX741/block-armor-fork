package twopiradians.blockArmor.packet;

import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent.Context;
import twopiradians.blockArmor.common.command.CommandDev;

public class SDevColorsPacket {
   public static void encode(SDevColorsPacket packet, FriendlyByteBuf buf) {
      ArrayList<UUID> keys = new ArrayList<>(CommandDev.devColors.keySet());
      int count = keys.size();
      buf.writeInt(count);

      for (int i = 0; i < count; i++) {
         buf.writeUtf(keys.get(i).toString());
         buf.writeFloat(CommandDev.devColors.get(keys.get(i))[0]);
         buf.writeFloat(CommandDev.devColors.get(keys.get(i))[1]);
         buf.writeFloat(CommandDev.devColors.get(keys.get(i))[2]);
      }
   }

   public static SDevColorsPacket decode(FriendlyByteBuf buf) {
      CommandDev.devColors = Maps.newHashMap();
      int count = buf.readInt();

      for (int i = 0; i < count; i++) {
         UUID uuid = UUID.fromString(buf.readUtf(32767));
         Float[] color = new Float[]{buf.readFloat(), buf.readFloat(), buf.readFloat()};
         CommandDev.devColors.put(uuid, color);
      }

      return new SDevColorsPacket();
   }

   public static class Handler {
      public static void handle(SDevColorsPacket packet, Supplier<Context> ctx) {
         ctx.get().setPacketHandled(true);
      }
   }
}
