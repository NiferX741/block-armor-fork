package twopiradians.blockArmor.utils;

import com.google.common.collect.Lists;
import java.lang.reflect.Field;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import twopiradians.blockArmor.common.seteffect.SetEffect;

public class BlockUtils {
   private static final Field MATERIAL_FIELD = ObfuscationReflectionHelper.findField(Properties.class, "f_60882_");
   private static final Field IS_SOLID_FIELD = ObfuscationReflectionHelper.findField(Properties.class, "f_60895_");
   private static final Field REQUIRES_TOOL_FIELD = ObfuscationReflectionHelper.findField(Properties.class, "f_60889_");

   public static Properties getProperties(Block block) {
      return Properties.copy(block);
   }

   public static Material getMaterial(Block block) {
      try {
         return (Material)MATERIAL_FIELD.get(getProperties(block));
      } catch (Exception var2) {
         return Material.AIR;
      }
   }

   public static float getHardness(Block block) {
      float blockHardness = 0.5F;

      try {
         blockHardness = block.defaultBlockState().getDestroySpeed(null, BlockPos.ZERO);
      } catch (Exception var3) {
         blockHardness = 0.5F;
      }

      return blockHardness;
   }

   public static float getBlastResistance(Block block) {
      return block.getExplosionResistance();
   }

   public static boolean getIsSolid(Block block) {
      try {
         return IS_SOLID_FIELD.getBoolean(getProperties(block));
      } catch (Exception var2) {
         return true;
      }
   }

   public static boolean getRequiresTool(Block block) {
      try {
         return REQUIRES_TOOL_FIELD.getBoolean(getProperties(block));
      } catch (Exception var2) {
         return true;
      }
   }

   public static int getLightLevel(Block block) {
      int lightLevel = block.defaultBlockState().getLightEmission();
      if (lightLevel <= 0) {
         Material material = getMaterial(block);
         if (SetEffect.registryNameContains(block, "lamp") || Lists.newArrayList(new Material[]{Material.BUILDABLE_GLASS}).contains(material)) {
            lightLevel = 15;
         }
      }

      return lightLevel;
   }
}
